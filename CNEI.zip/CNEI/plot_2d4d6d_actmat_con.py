# # import pandas as pd
# # import matplotlib.pyplot as plt
# # import matplotlib
# # matplotlib.use('TkAgg')
# # import numpy as np
# # import os, re
# #
# # # ── 配置 ──────────────────────────────────────────────
# # DATA_DIR    = r"D:\python code\linked_bo\bo_results\data"
# # OUTPUT_FILE = r"D:\python code\linked_bo\bo_results\convergence_2d4d6d.pdf"
# # TARGET_RATIO = "1:9"   # cost ratio
# # Y_MIN        = 0       # log10(y - y_min) 中的 y_min
# # # ──────────────────────────────────────────────────────
# #
# # plt.rcParams['font.family'] = 'Times New Roman'
# # plt.rcParams['font.size'] = 14        # 全局基础字号
# # plt.rcParams['axes.titlesize'] = 15   # 子图标题
# # plt.rcParams['axes.labelsize'] = 14   # 轴标签
# # plt.rcParams['xtick.labelsize'] = 13  # x轴刻度
# # plt.rcParams['ytick.labelsize'] = 13  # y轴刻度
# # plt.rcParams['legend.fontsize'] = 13  # 图例
# #
# # # algos 用于匹配文件名中的内部名称，顺序即控制图例顺序
# # algos  = ['EI', 'EIFN', 'EILGP', 'CLEI']
# # dims   = ['2D', '4D', '6D']
# # colors = {'EI': '#1f77b4', 'CLEI': '#ff7f0e', 'EIFN': '#2ca02c', 'EILGP': '#d62728'}
# #
# # # 显示名称映射：内部仍用 CLEI 匹配文件，但展示时改为 CNEI
# # display_name = {'EI': 'EI', 'EIFN': 'EIFN', 'EILGP': 'EILGP', 'CLEI': 'CNEI'}
# #
# # files = sorted([
# #     f for f in os.listdir(DATA_DIR)
# #     if "convergence" in f and f.endswith(".xlsx")
# # ])
# #
# # # 解析所有文件：按维度和算法存储
# # data = {}   # data[dim][algo] = (costs, mean, std)
# #
# # for f in files:
# #     m = re.search(r'(\d+D)_(\d+)_(\d+)_(\w+)_convergence', f)
# #     if not m:
# #         continue
# #     dim, c1, c2, algo = m.group(1), m.group(2), m.group(3), m.group(4)
# #     if f"{c1}:{c2}" != TARGET_RATIO:
# #         continue
# #
# #     df    = pd.read_excel(os.path.join(DATA_DIR, f))
# #     costs = df['cumulative_cost'].values
# #     vals  = df.iloc[:, 1:].values  # shape: (n_iters, 100)
# #
# #     shifted  = np.where(vals - Y_MIN > 0, vals - Y_MIN, np.nan)
# #     log_vals = np.log10(shifted)
# #     mean = np.nanmean(log_vals, axis=1)
# #     std  = np.nanstd(log_vals, axis=1)
# #
# #     if dim not in data:
# #         data[dim] = {}
# #     data[dim][algo] = (costs, mean, std)
# #
# # # ── 绘图 ──────────────────────────────────────────────
# # fig, axes = plt.subplots(1, 3, figsize=(16, 5))
# #
# # for ax, dim in zip(axes, dims):
# #     for algo in algos:
# #         if algo not in data.get(dim, {}):
# #             continue
# #         costs, mean, std = data[dim][algo]
# #         ax.plot(costs, mean, color=colors[algo], label=display_name.get(algo, algo), linewidth=1.8)
# #         ax.fill_between(costs, mean - std, mean + std, color=colors[algo], alpha=0.2)
# #     ax.set_xlabel('Cumulative Cost', fontsize=14)
# #     ax.set_ylabel(r'$\log_{10}(y - y_{\min})$', fontsize=14)
# #     ax.legend()
# #     ax.grid(True, alpha=0.3)
# #     ax.set_title(dim, fontsize=14, fontweight='bold')
# #
# # plt.tight_layout()
# # plt.savefig(OUTPUT_FILE, bbox_inches='tight')
# # print(f"Saved to {OUTPUT_FILE}")
# # plt.show()
#
# """
# 1x3 convergence figure: best objective value vs cumulative cost, cost ratio 1:9,
# for dimensions 2D / 4D / 6D. Four methods (EI, EIFN, EILGP, CLEI).
# Same style as the single left convergence panel (log-y, mean +/- SE band).
#
# Reads {DIM}_1_9_{METHOD}_convergence.xlsx from this folder.
# """
# import os
# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
#
# DATA_DIR    = r"D:\python code\linked_bo\bo_results\data"
# RATIO = "1_9"                 # cost ratio 1:9
# DIMS = ["2D", "4D", "6D"]
# METHODS = ["EI", "EIFN", "EILGP", "CLEI"]
# BAND = "se"                   # "se" | "std" | "iqr" | "none"
# YLOG = True
# OUT_PDF = os.path.join(DATA_DIR, "convergence_2d4d6d_1_9_v2.pdf")
#
# COLORS = {"EI": "#1f77b4", "EIFN": "#ff7f0e", "EILGP": "#2ca02c", "CLEI": "#d62728"}
#
# # ---- fonts (match paper body text) ----
# plt.rcParams["font.family"] = "serif"
# plt.rcParams["font.serif"] = ["Times New Roman", "Liberation Serif",
#                               "Nimbus Roman", "DejaVu Serif"]
# plt.rcParams["mathtext.fontset"] = "dejavuserif"
# plt.rcParams["axes.unicode_minus"] = False
# plt.rcParams.update({
#     "font.size": 16, "axes.labelsize": 18, "xtick.labelsize": 15,
#     "ytick.labelsize": 15, "legend.fontsize": 15, "axes.linewidth": 1.0,
# })
#
# def band(vals):
#     n = vals.shape[1]
#     mean, std = vals.mean(axis=1), vals.std(axis=1)
#     if BAND == "se":
#         return mean, mean - std/np.sqrt(n), mean + std/np.sqrt(n)
#     if BAND == "std":
#         return mean, mean - std, mean + std
#     if BAND == "iqr":
#         return (np.median(vals, axis=1),
#                 np.percentile(vals, 25, axis=1), np.percentile(vals, 75, axis=1))
#     return mean, mean, mean
#
# _ylab = {"se": "mean $\\pm$ SE", "std": "mean $\\pm$ std",
#          "iqr": "median + IQR", "none": "mean"}[BAND]
#
# fig, axes = plt.subplots(1, 3, figsize=(19, 5.8), sharey=False)
# sub = ["(a)", "(b)", "(c)"]
#
# for ax, dim, tag in zip(axes, DIMS, sub):
#     for m in METHODS:
#         f = os.path.join(DATA_DIR, f"{dim}_{RATIO}_{m}_convergence.xlsx")
#         df = pd.read_excel(f)
#         cost = df["cumulative_cost"].values.astype(float)
#         vals = df.drop(columns=["cumulative_cost"]).values.astype(float)
#         center, lo, hi = band(vals)
#         if not YLOG:
#             lo = np.clip(lo, 0, None)
#         ax.plot(cost, center, label=m, color=COLORS[m], linewidth=2.2)
#         if BAND != "none":
#             ax.fill_between(cost, lo, hi, color=COLORS[m], alpha=0.15)
#     if YLOG:
#         ax.set_yscale("log")
#     ax.set_xlim(cost.min(), cost.max())
#     ax.grid(True, which="both", ls="--", lw=0.5, alpha=0.5)
#     ax.set_xlabel("Cumulative cost")
#     ax.set_ylabel("Best value found (" + _ylab + ")")
#     ax.legend(frameon=False, loc="lower left")
#     ax.text(0.5, -0.22, f"{tag} {dim}", transform=ax.transAxes,
#             ha="center", va="top", fontsize=17)
#
# fig.suptitle("Convergence of the best objective value over 100 replications "
#              "(cost ratio 1:9)", fontsize=18, y=1.02)
# fig.tight_layout()
# fig.subplots_adjust(bottom=0.18)
# fig.savefig(OUT_PDF, bbox_inches="tight")
# print("saved:", OUT_PDF)

"""
1x3 convergence figure: best objective value vs cumulative cost, cost ratio 1:9,
for dimensions 2D / 4D / 6D. Four methods (EI, EIFN, EILGP, CLEI).
Same style as the single left convergence panel (log-y, mean +/- SE band).

Reads {DIM}_1_9_{METHOD}_convergence.xlsx from this folder.
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR    = r"D:\python code\linked_bo\bo_results\data"
RATIO = "1_9"                 # cost ratio 1:9
DIMS = ["2D", "4D", "6D"]
METHODS = ["EI", "EIFN", "EILGP", "CLEI"]
LABELS = {"CLEI": "CNEI"}   # display name only; files stay CLEI
BAND = "sem95"                # "se" | "sem95" | "std" | "iqr" | "none"
YLOG = True
OUT_PDF = os.path.join(DATA_DIR, "convergence_2d4d6d_1_9_styled.pdf")

COLORS = {"EI": "#1f77b4", "EIFN": "#ff7f0e", "EILGP": "#2ca02c", "CLEI": "#d62728"}
STYLES = {"EI": ":", "EIFN": "-.", "EILGP": "--", "CLEI": "-"}   # line styles

# ---- fonts (match paper body text) ----
plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Times New Roman", "Liberation Serif",
                              "Nimbus Roman", "DejaVu Serif"]
plt.rcParams["mathtext.fontset"] = "dejavuserif"
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams.update({
    "font.size": 18, "axes.labelsize": 21, "xtick.labelsize": 17,
    "ytick.labelsize": 17, "legend.fontsize": 17, "axes.linewidth": 1.0,
})

def band(vals):
    n = vals.shape[1]
    mean, std = vals.mean(axis=1), vals.std(axis=1)
    if BAND == "se":
        return mean, mean - std/np.sqrt(n), mean + std/np.sqrt(n)
    if BAND == "sem95":
        try:
            from scipy.stats import t as _t
            tv = _t.ppf(0.975, n - 1)
        except Exception:
            tv = 1.96
        h = tv * std / np.sqrt(n)
        return mean, mean - h, mean + h
    if BAND == "std":
        return mean, mean - std, mean + std
    if BAND == "iqr":
        return (np.median(vals, axis=1),
                np.percentile(vals, 25, axis=1), np.percentile(vals, 75, axis=1))
    return mean, mean, mean

_ylab = {"se": "mean $\\pm$ SE", "sem95": "mean, 95% CI",
         "std": "mean $\\pm$ std", "iqr": "median + IQR", "none": "mean"}[BAND]

fig, axes = plt.subplots(1, 3, figsize=(19, 5.8), sharey=False)
sub = ["(a)", "(b)", "(c)"]

for ax, dim, tag in zip(axes, DIMS, sub):
    pmin = np.inf
    for m in METHODS:
        f = os.path.join(DATA_DIR, f"{dim}_{RATIO}_{m}_convergence.xlsx")
        df = pd.read_excel(f)
        cost = df["cumulative_cost"].values.astype(float)
        vals = df.drop(columns=["cumulative_cost"]).values.astype(float)
        center, lo, hi = band(vals)
        if not YLOG:
            lo = np.clip(lo, 0, None)
        ax.plot(cost, center, label=LABELS.get(m, m), color=COLORS[m],
            linestyle=STYLES[m], linewidth=2.2)
        if BAND != "none":
            ax.fill_between(cost, lo, hi, color=COLORS[m], alpha=0.15)
        pmin = min(pmin, np.min(lo[lo > 0]) if YLOG else np.min(lo))
    if YLOG:
        ax.set_yscale("log")
    ax.set_xlim(cost.min(), cost.max())
    top = ax.get_ylim()[1]
    bfac = {"2D": 0.55, "4D": 0.72, "6D": 0.82}[dim]
    ax.set_ylim(bottom=pmin * bfac, top=top)
    ax.grid(True, which="both", ls="--", lw=0.5, alpha=0.5)
    ax.set_xlabel("Cumulative cost")
    ax.set_ylabel("Best value found (" + _ylab + ")")
    ax.legend(loc="lower left", frameon=False)
    ax.set_title(f"{tag} {dim}", fontsize=20, pad=10)

fig.tight_layout()
fig.savefig(OUT_PDF, bbox_inches="tight")
print("saved:", OUT_PDF)