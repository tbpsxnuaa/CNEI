"""
gpnet_3node.py
==================
基于 GP-sample 函数网络测试问题（并行两节点第一层），对
CLEI / EILGP / EIFN / EI 四种方法各运行 N_REPS 次独立重复实验。

函数网络结构
-----------
  第一层（并行两过程）：
    · f1(x1) → y1,  x1 ∈ [-2, 2] GP sample，RBF 核，length_scale=0.2，output_scale=2.0
    · f2(x2) → y2,  x2 ∈ [-2, 2] GP sample，RBF 核，length_scale=0.5，output_scale=2.0
  第二层：
    · f3(y1, y2, x3) → y3,  x3 ∈ [-2, 2] GP sample，RBF 核，length_scale=[0.1,0.2,0.9]，output_scale=2.0
  目标：最小化 y3

代价设置
-----------
  · COST_LAYER1_P1 = 1.0   （运行 f1 的代价）
  · COST_LAYER1_P2 = 1.0   （运行 f2 的代价）
  · COST_LAYER1    = 2.0   （同时运行 f1+f2 的总代价）
  · COST_LAYER2    = 18.0  （运行 f3 的代价）
  · COST_BOTH      = 20.0  （三者全运行的总代价，EI/EIFN/EILGP 每步仍用它）

CLEI 策略说明（本版本已移除 'both' 联合采集选项）
-----------
  CLEI 每次迭代只在三种"按节点划分"的采集函数之间比较、三选一：
    · 'layer1f1'    : 仅运行 f1（采新 x1），代价=COST_LAYER1_P1
    · 'layer1f2'    : 仅运行 f2（采新 x2），代价=COST_LAYER1_P2
    · 'layer2_reuse': 复用已有 (y1,y2) 值，仅以新 x3 运行 f3，代价=COST_LAYER2
  不再存在"新采 (x1,x2,x3) 全部运行"的 'both' 选项。

CLEI 采集函数定义
-----------
  上游节点 f1 的 incremental benefit：
    ei_f1_benefit = EI_joint - max_{x1 ∈ X1_obs} max_{x2,x3} EI_LGP(x1, x2, x3)
  上游节点 f2 的 incremental benefit：
    ei_f2_benefit = EI_joint - max_{x2 ∈ X2_obs} max_{x1,x3} EI_LGP(x1, x2, x3)
  下游节点 f3（复用）：
    ei_l2r = max_{(y1,y2) ∈ obs} max_{x3} EI_f3(y1, y2, x3)

  其中 EI_joint = max_{x1,x2,x3} EI_LGP(x1, x2, x3) 只用于估计上游两个节点的
  边际信息价值（作为参照基准），这个联合优化点本身不会被当作 'both' 采样
  —— CLEI 不会真的一次性联合采 (x1,x2,x3)。

  每代价采集函数：alpha_v^cost = benefit_v / cost_v
  选择 argmax 对应节点评估（三选一：layer1f1 / layer1f2 / layer2_reuse）。

LGP 链接说明（dgpsi 语法）
-----------
  第一层两个 container：
    c1: local_input_idx=np.array([0])   → 全局输入第 0 列 (x1)
    c2: local_input_idx=np.array([1])   → 全局输入第 1 列 (x2)
  第二层一个 container（接收 y1, y2 及外部 x3）：
    GP 核：input_dim=np.array([0,1])（来自第一层输出 y1,y2），
           connect=np.array([2])（全局输入第 2 列 x3）
    c3: local_input_idx=[np.array([0,1])]  （第一层全部两个输出）
  predict 时：
    x = [X_global_12,        # shape (n,2)：第一层的全局输入 (x1,x2)
         [x3_ext]]            # 长度 1 的列表：第二层的外部全局输入 x3，shape (n,1)

异常处理策略（本版本新增）
-----------
  四种方法各自内部仍保留"连续 max_retries 次拟合/优化异常"的重试机制
  （给偶发数值抖动一个自愈的机会）。但如果某个方法把重试次数用尽仍然
  失败，不再默默保留该方法此前的部分结果、跳过继续——而是直接抛出异常，
  导致 _run_one() 整体失败。run_all_reps() 捕获到这种失败后，会**丢弃
  这一整次重复（四种方法的结果都不要）**，换一个新的随机种子重新完整
  跑一次，直到成功（四种方法都跑满预算、没有异常）才把结果计入第 i 次
  重复。这样保存到 pkl / 参与汇总统计的，永远都是"四种方法全部正常跑
  完"的干净结果。
"""

import os
import pickle
import warnings
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm
from scipy.interpolate import RegularGridInterpolator
from scipy.spatial.distance import cdist

from dgpsi import kernel, container, lgp, gp
from pyDOE2 import lhs

# =============================================================================
# GP-sample 工具
# =============================================================================


def _rbf_kernel(X1, X2, length_scale, output_scale=1.0):
    X1 = np.atleast_2d(X1)
    X2 = np.atleast_2d(X2)
    if np.isscalar(length_scale):
        X1s = X1 / length_scale
        X2s = X2 / length_scale
    else:
        X1s = X1 / np.array(length_scale)
        X2s = X2 / np.array(length_scale)
    dists = cdist(X1s, X2s, metric='sqeuclidean')
    return output_scale * np.exp(-0.5 * dists)


def _sample_gp_path(grid_points_list, length_scale, output_scale, seed):
    grids = np.meshgrid(*grid_points_list, indexing='ij')
    X_grid = np.column_stack([g.ravel() for g in grids])
    K = _rbf_kernel(X_grid, X_grid, length_scale, output_scale)
    K += 1e-8 * np.eye(len(X_grid))
    rng = np.random.default_rng(seed)
    L_mat = np.linalg.cholesky(K)
    z = rng.standard_normal(len(X_grid))
    f_vals = L_mat @ z
    shape = tuple(len(g) for g in grid_points_list)
    return RegularGridInterpolator(
        grid_points_list, f_vals.reshape(shape),
        method='linear', bounds_error=False, fill_value=None)


# =============================================================================
# 全局参数
# =============================================================================
DIM_X1 = 1
DIM_X2 = 1
DIM_X3 = 1
DIM_GLOBAL = DIM_X1 + DIM_X2 + DIM_X3   # = 3

COST_LAYER1_P1 = 1.0
COST_LAYER1_P2 = 1.0
COST_LAYER1    = COST_LAYER1_P1 + COST_LAYER1_P2   # = 2.0
COST_LAYER2    = 8.0
COST_BOTH      = COST_LAYER1 + COST_LAYER2          # = 20.0

SEQUENTIAL_BUDGET = 500.0
N_REPS    = 100
BASE_SEED = 1

MAX_ATTEMPTS_PER_REP = 50  # 单次重复最多重新开始多少次（换新种子重试的上限，防止极端情况下死循环）

SAVE_DIR  = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = os.path.join(SAVE_DIR, 's1_gpnet3_parallel_results.pkl')

N_INIT = 2 * (DIM_GLOBAL + 1)   # = 8

COST_AXIS = np.arange(0, SEQUENTIAL_BUDGET + COST_LAYER1_P1, COST_LAYER1_P1)

METHODS = ['EI', 'EIFN', 'EILGP', 'CLEI']
BOUNDS  = [(-2.0, 2.0)] * DIM_GLOBAL

# ── 构造 GP-sample 函数 ──
_X1_GRID = np.linspace(-2.0, 2.0, 201)
_X2_GRID = np.linspace(-2.0, 2.0, 201)

_F1_INTERP = _sample_gp_path([_X1_GRID], 0.1, 2.0, seed=88)
_F2_INTERP = _sample_gp_path([_X2_GRID], 0.9, 2.0, seed=42)

_Y1_PROBE = _F1_INTERP(np.linspace(-2, 2, 400).reshape(-1, 1)).flatten()
_Y2_PROBE = _F2_INTERP(np.linspace(-2, 2, 400).reshape(-1, 1)).flatten()
_Y1_LO = _Y1_PROBE.min() - 0.5
_Y1_HI = _Y1_PROBE.max() + 0.5
_Y2_LO = _Y2_PROBE.min() - 0.5
_Y2_HI = _Y2_PROBE.max() + 0.5

_Y1G = np.linspace(_Y1_LO, _Y1_HI, 21)
_Y2G = np.linspace(_Y2_LO, _Y2_HI, 21)
_X3G = np.linspace(-2.0, 2.0, 21)

_F3_INTERP = _sample_gp_path(
    [_Y1G, _Y2G, _X3G], [0.1, 0.1, 0.9], 6.0, seed=185)


def f1(x1):
    """x1 (n,1) → y1 (n,1)"""
    return _F1_INTERP(np.atleast_2d(x1).reshape(-1, 1)).reshape(-1, 1)


def f2(x2):
    """x2 (n,1) → y2 (n,1)"""
    return _F2_INTERP(np.atleast_2d(x2).reshape(-1, 1)).reshape(-1, 1)


def f3(y1, y2, x3):
    """(y1,y2,x3) → y3 (n,1)"""
    pts = np.hstack([np.atleast_2d(y1).reshape(-1, 1),
                     np.atleast_2d(y2).reshape(-1, 1),
                     np.atleast_2d(x3).reshape(-1, 1)])
    return _F3_INTERP(pts).reshape(-1, 1)


def simulate_all(x1, x2, x3):
    y1 = f1(x1)
    y2 = f2(x2)
    y3 = f3(y1, y2, x3)
    return y1, y2, y3


# =============================================================================
# EI 计算
# =============================================================================


def EI_from_ml_vl(ml, vl, best_f, xi=0.0):
    sigma = np.sqrt(np.maximum(vl, 1e-12))
    improvement = best_f - ml - xi
    u = improvement / sigma
    return improvement * norm.cdf(u) + sigma * norm.pdf(u)


# =============================================================================
# LGP 辅助
# =============================================================================


def fit_gp_f1(X1, Y1):
    m = gp(X1, Y1,
           kernel(length=np.ones(DIM_X1), nugget=1e-6,
                  name='matern2.5', scale_est=True))
    m.train()
    return m


def fit_gp_f2(X2, Y2):
    m = gp(X2, Y2,
           kernel(length=np.ones(DIM_X2), nugget=1e-6,
                  name='matern2.5', scale_est=True))
    m.train()
    return m


def fit_gp_f3(X3_full, Y3):
    """X3_full = [y1, y2, x3] (n, 3)"""
    m = gp(X3_full, Y3,
           kernel(length=np.ones(3), nugget=1e-6,
                  name='matern2.5', scale_est=True,
                  input_dim=np.array([0, 1]),
                  connect=np.array([2])))
    m.train()
    return m


def build_lgp_model(m_f1, m_f2, m_f3):
    c1 = container(m_f1.export(), local_input_idx=np.array([0]))
    c2 = container(m_f2.export(), local_input_idx=np.array([1]))
    c3 = container(m_f3.export(), local_input_idx=[np.array([0, 1])])
    return lgp([[c1, c2], [c3]], N=10)


def build_lgp_input(x):
    x = np.asarray(x).reshape(-1)
    X_global_12 = x[:2].reshape(1, -1)
    x3_ext = x[2:3].reshape(1, -1)
    return [X_global_12, [x3_ext]]


def lgp_predict(model_lgp, x):
    inp = build_lgp_input(x)
    ml_list, vl_list = model_lgp.predict(inp)
    return ml_list[0][0, 0], vl_list[0][0, 0]


def standard_EI(x, model_lgp, best_f):
    ml, vl = lgp_predict(model_lgp, x)
    return EI_from_ml_vl(ml, vl, best_f)


# =============================================================================
# EIFN（函数网络 EI，SAA 采样）
# =============================================================================


class EIFN_Optimizer:
    def __init__(self, bounds, n_samples=50, n_restarts=15):
        self.bounds = bounds
        self.n_samples = n_samples
        self.n_restart = n_restarts
        self.X1_data = self.Y1_data = None
        self.X2_data = self.Y2_data = None
        self.X3_full = self.Y3_data = None
        self.gp_f1 = self.gp_f2 = self.gp_f3 = None
        self.best_y3 = np.inf

    def add_observation(self, x1, x2, x3):
        x1, x2, x3 = float(x1), float(x2), float(x3)
        y1, y2, y3 = simulate_all(
            np.array([[x1]]), np.array([[x2]]), np.array([[x3]]))
        row_x1  = np.array([[x1]])
        row_x2  = np.array([[x2]])
        row_x3f = np.hstack((y1, y2, np.array([[x3]])))
        if self.X1_data is None:
            self.X1_data = row_x1;  self.Y1_data = y1
            self.X2_data = row_x2;  self.Y2_data = y2
            self.X3_full = row_x3f; self.Y3_data = y3
        else:
            self.X1_data = np.vstack((self.X1_data, row_x1))
            self.Y1_data = np.vstack((self.Y1_data, y1))
            self.X2_data = np.vstack((self.X2_data, row_x2))
            self.Y2_data = np.vstack((self.Y2_data, y2))
            self.X3_full = np.vstack((self.X3_full, row_x3f))
            self.Y3_data = np.vstack((self.Y3_data, y3))
        self.best_y3 = min(self.best_y3, float(y3))
        return y3

    def update_models(self):
        self.gp_f1 = fit_gp_f1(self.X1_data, self.Y1_data)
        self.gp_f2 = fit_gp_f2(self.X2_data, self.Y2_data)
        self.gp_f3 = fit_gp_f3(self.X3_full, self.Y3_data)

    def _sample_posterior(self, x, Z):
        x1, x2, x3 = x[0], x[1], x[2]
        mu1, v1 = self.gp_f1.predict(np.array([[x1]]))
        y1s = mu1.flat[0] + np.sqrt(max(v1.flat[0], 1e-12)) * Z[0]
        mu2, v2 = self.gp_f2.predict(np.array([[x2]]))
        y2s = mu2.flat[0] + np.sqrt(max(v2.flat[0], 1e-12)) * Z[1]
        mu3, v3 = self.gp_f3.predict(np.array([[y1s, y2s, x3]]))
        return mu3.flat[0] + np.sqrt(max(v3.flat[0], 1e-12)) * Z[2]

    def compute_ei_saa(self, x, Z_samples):
        return np.mean([max(self.best_y3 - self._sample_posterior(x, Z), 0)
                        for Z in Z_samples])

    def optimize_acquisition(self):
        Z_samples = np.random.randn(self.n_samples, 3)
        best_x, best_ei = None, -np.inf
        for _ in range(self.n_restart):
            x0 = np.array([np.random.uniform(b[0], b[1]) for b in self.bounds])
            res = minimize(lambda x: -self.compute_ei_saa(x, Z_samples),
                           x0, bounds=self.bounds, method='L-BFGS-B')
            if res.success and -res.fun > best_ei:
                best_ei = -res.fun
                best_x = res.x
        if best_x is None:
            best_x = np.array([np.random.uniform(b[0], b[1]) for b in self.bounds])
        return best_x, best_ei


# =============================================================================
# CLEI 辅助函数
# =============================================================================


def _optimize_layer2_reuse(Y1_data, Y2_data, m_f3, best_f,
                            x3_bounds, n_restart=15):
    """
    复用已有 (y1, y2) 对，对每对遍历优化 x3，取全局最优。
    返回 (best_y1, best_y2, best_x3, best_ei)
    """
    best_y1 = best_y2 = best_x3 = None
    best_ei = -1e20
    n = min(len(Y1_data), len(Y2_data))
    for i in range(n):
        y1c = float(Y1_data[i, 0])
        y2c = float(Y2_data[i, 0])
        best_ei_local = -1e20
        best_x3_local = None
        for _ in range(n_restart):
            x3_init = np.random.uniform(x3_bounds[0], x3_bounds[1])

            def obj(xp, y1c=y1c, y2c=y2c):
                ml, vl = m_f3.predict(np.array([[y1c, y2c, xp[0]]]))
                return -EI_from_ml_vl(ml.flat[0], vl.flat[0], best_f)

            res = minimize(obj, [x3_init], bounds=[x3_bounds], method='L-BFGS-B')
            if res.success:
                xp = res.x[0]
                ml, vl = m_f3.predict(np.array([[y1c, y2c, xp]]))
                ei = EI_from_ml_vl(ml.flat[0], vl.flat[0], best_f)
                if ei > best_ei_local:
                    best_ei_local = ei
                    best_x3_local = xp
        if best_ei_local > best_ei:
            best_ei  = best_ei_local
            best_y1  = y1c
            best_y2  = y2c
            best_x3  = best_x3_local
    return best_y1, best_y2, best_x3, best_ei


def _optimize_joint_marginal(model_lgp, best_f, bounds, n_restart=15):
    """
    在全局输入空间 (x1, x2, x3) 上最大化 LGP-EI。
    这个联合优化结果仅用于估计上游节点 f1 / f2 的边际信息价值（作为参照
    基准），本身不会被当作 'both' 采样动作——CLEI 不会真的一次性联合采
    (x1,x2,x3)。
    返回 (best_x, best_ei)
    """
    best_x, best_ei = None, -1e20
    for _ in range(n_restart):
        x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
        res = minimize(lambda x: -standard_EI(x, model_lgp, best_f),
                       x0, bounds=bounds, method='L-BFGS-B')
        if res.success and -res.fun > best_ei:
            best_ei = -res.fun
            best_x  = res.x
    if best_x is None:
        best_x  = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
        best_ei = standard_EI(best_x, model_lgp, best_f)
    return best_x, best_ei


def _optimize_fixed_x1(x1_fixed, model_lgp, best_f, bounds, n_restart=15):
    """
    固定 x1=x1_fixed，在 (x2, x3) 上最大化 LGP-EI。
    返回 (best_ei, (best_x2, best_x3))
    """
    best_ei = -1e20
    best_x2 = best_x3 = None
    x2_bounds = bounds[1]
    x3_bounds = bounds[2]
    for _ in range(n_restart):
        x0 = np.array([np.random.uniform(x2_bounds[0], x2_bounds[1]),
                        np.random.uniform(x3_bounds[0], x3_bounds[1])])

        def obj(vars, x1_fixed=x1_fixed):
            x_full = np.array([x1_fixed, vars[0], vars[1]])
            return -standard_EI(x_full, model_lgp, best_f)

        res = minimize(obj, x0, bounds=[x2_bounds, x3_bounds], method='L-BFGS-B')
        if res.success and -res.fun > best_ei:
            best_ei = -res.fun
            best_x2, best_x3 = res.x
    return best_ei, (best_x2, best_x3)


def _optimize_fixed_x2(x2_fixed, model_lgp, best_f, bounds, n_restart=15):
    """
    固定 x2=x2_fixed，在 (x1, x3) 上最大化 LGP-EI。
    返回 (best_ei, (best_x1, best_x3))
    """
    best_ei = -1e20
    best_x1 = best_x3 = None
    x1_bounds = bounds[0]
    x3_bounds = bounds[2]
    for _ in range(n_restart):
        x0 = np.array([np.random.uniform(x1_bounds[0], x1_bounds[1]),
                        np.random.uniform(x3_bounds[0], x3_bounds[1])])

        def obj(vars, x2_fixed=x2_fixed):
            x_full = np.array([vars[0], x2_fixed, vars[1]])
            return -standard_EI(x_full, model_lgp, best_f)

        res = minimize(obj, x0, bounds=[x1_bounds, x3_bounds], method='L-BFGS-B')
        if res.success and -res.fun > best_ei:
            best_ei = -res.fun
            best_x1, best_x3 = res.x
    return best_ei, (best_x1, best_x3)


def _baseline_fixed_x1(X1_data, model_lgp, best_f, bounds, n_restart=15):
    """
    f1 的基准：遍历所有已观测 x1，固定后优化 (x2, x3)，取最大 EI。
    语义：不新采 f1 时，利用已有 x1 能得到的最好 LGP-EI。
    返回 (best_ei, (best_x1_used, best_x2, best_x3))
    """
    best_ei = -1e20
    best_x1_used = best_x2 = best_x3 = None
    for x1_obs in X1_data.flatten():
        ei_local, (x2_opt, x3_opt) = _optimize_fixed_x1(
            x1_obs, model_lgp, best_f, bounds, n_restart)
        if ei_local > best_ei:
            best_ei      = ei_local
            best_x1_used = x1_obs
            best_x2      = x2_opt
            best_x3      = x3_opt
    return best_ei, (best_x1_used, best_x2, best_x3)


def _baseline_fixed_x2(X2_data, model_lgp, best_f, bounds, n_restart=15):
    """
    f2 的基准：遍历所有已观测 x2，固定后优化 (x1, x3)，取最大 EI。
    语义：不新采 f2 时，利用已有 x2 能得到的最好 LGP-EI。
    返回 (best_ei, (best_x1, best_x2_used, best_x3))
    """
    best_ei = -1e20
    best_x1 = best_x2_used = best_x3 = None
    for x2_obs in X2_data.flatten():
        ei_local, (x1_opt, x3_opt) = _optimize_fixed_x2(
            x2_obs, model_lgp, best_f, bounds, n_restart)
        if ei_local > best_ei:
            best_ei      = ei_local
            best_x1      = x1_opt
            best_x2_used = x2_obs
            best_x3      = x3_opt
    return best_ei, (best_x1, best_x2_used, best_x3)


def _clei_strategy(model_lgp, m_f3, Y1_data, Y2_data, X1_data, X2_data,
                   best_f, bounds, n_restart=15):
    """
    CLEI 策略选择（已移除 'both' 联合采集选项）。

    每次迭代只在三种"按节点划分"的采集函数之间三选一：
      - layer1f1:     alpha = (EI_joint - baseline_f1) / COST_LAYER1_P1
      - layer1f2:     alpha = (EI_joint - baseline_f2) / COST_LAYER1_P2
      - layer2_reuse: alpha = EI_l2r / COST_LAYER2

    其中：
      baseline_f1 = max_{x1 ∈ X1_obs} max_{x2,x3} EI_LGP(x1, x2, x3)
      baseline_f2 = max_{x2 ∈ X2_obs} max_{x1,x3} EI_LGP(x1, x2, x3)
      EI_joint    = max_{x1,x2,x3} EI_LGP(x1, x2, x3)  （仅用于估值，不采样）

    新采点：
      layer1f1 → 新采 x1 = x_joint[0]（使 EI_joint 最大的点）
      layer1f2 → 新采 x2 = x_joint[1]
    """
    # 1. 全链联合 EI（仅用于估计上游节点边际价值，不作为采样候选）
    x_joint, ei_joint = _optimize_joint_marginal(model_lgp, best_f, bounds, n_restart)

    # 2. 复用已有 (y1,y2)，仅优化 x3
    y1r, y2r, x3r, ei_l2r = _optimize_layer2_reuse(
        Y1_data, Y2_data, m_f3, best_f, bounds[2], n_restart)

    # 3. f1 基准：遍历已观测 x1，固定后优化 (x2, x3)
    ei_f1_base, _ = _baseline_fixed_x1(
        X1_data, model_lgp, best_f, bounds, n_restart)

    # 4. f2 基准：遍历已观测 x2，固定后优化 (x1, x3)
    ei_f2_base, _ = _baseline_fixed_x2(
        X2_data, model_lgp, best_f, bounds, n_restart)

    # 5. Incremental benefit（下界截零）
    ei_f1_benefit = max(ei_joint - ei_f1_base, 0.0)
    ei_f2_benefit = max(ei_joint - ei_f2_base, 0.0)

    # 6. 每代价采集函数值
    ei_pc_f1   = ei_f1_benefit / COST_LAYER1_P1
    ei_pc_f2   = ei_f2_benefit / COST_LAYER1_P2
    ei_pc_l2r  = ei_l2r        / COST_LAYER2

    # 7. 候选点构造（三选一，不再有 'both'）
    #    layer1f1：新采 x1=x_joint[0]，x2/x3 占位（执行时不使用）
    #    layer1f2：新采 x2=x_joint[1]，x1/x3 占位（执行时不使用）
    candidates = {
        'layer1f1':     (ei_pc_f1,   np.array([x_joint[0], x_joint[1], x_joint[2]])),
        'layer1f2':     (ei_pc_f2,   np.array([x_joint[0], x_joint[1], x_joint[2]])),
        'layer2_reuse': (ei_pc_l2r,  np.array([y1r, y2r, x3r])),
    }
    strategy, (ei_per_cost, opt_x) = max(
        candidates.items(), key=lambda kv: kv[1][0])

    return strategy, opt_x, (ei_f1_benefit, ei_f2_benefit, ei_l2r, ei_joint)


# =============================================================================
# best-so-far 曲线工具
# =============================================================================


def _bsf_curve(cost_log, y3_log, cost_axis=COST_AXIS):
    curve = np.full(len(cost_axis), np.nan)
    if len(cost_log) == 0:
        return curve
    cost_log = np.asarray(cost_log)
    y3_log   = np.asarray(y3_log)
    bsf = y3_log[0]
    ci  = 0
    for c, y in zip(cost_log, y3_log):
        bsf = min(bsf, y)
        while ci < len(cost_axis) and cost_axis[ci] <= c + 1e-9:
            curve[ci] = bsf
            ci += 1
    curve[ci:] = bsf
    return curve


# =============================================================================
# 单次实验
# =============================================================================


def _run_one(seed):
    """
    运行一次完整实验，返回：
      {method: {'bsf': best-so-far 曲线, 'final_best': 最终最优值}}

    任何一种方法如果连续 max_retries 次拟合/优化异常，不再悄悄保留该
    方法此前的部分结果并继续——而是直接抛出异常，让调用方（run_all_reps）
    知道这次尝试整体失败，需要丢弃重来。
    """
    np.random.seed(seed)
    bounds      = BOUNDS
    max_retries = 5

    # 初始 LHS
    unit   = lhs(DIM_GLOBAL, samples=N_INIT, criterion='maximin')
    X_init = np.array([lo + (hi - lo) * unit[:, i]
                       for i, (lo, hi) in enumerate(bounds)]).T

    X1_init = X_init[:, 0:1]
    X2_init = X_init[:, 1:2]
    X3_init = X_init[:, 2:3]

    Y1_init      = f1(X1_init)
    Y2_init      = f2(X2_init)
    X3_full_init = np.hstack((Y1_init, Y2_init, X3_init))
    Y3_init      = f3(Y1_init, Y2_init, X3_init)

    results = {}

    # ====================================================================
    # EI（黑箱）
    # ====================================================================
    X_ei = X_init.copy()
    Y_ei = Y3_init.copy()
    cost_c   = 0.0
    failed   = 0
    cost_log = [0.0]
    y3_log   = [float(Y3_init.min())]

    while cost_c + COST_BOTH <= SEQUENTIAL_BUDGET:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                m_ei = gp(X_ei, Y_ei,
                          kernel(length=np.ones(DIM_GLOBAL), nugget=1e-6,
                                 name='matern2.5', scale_est=True))
                m_ei.train()
            bf = Y_ei.min()

            def acq(x):
                ml, vl = m_ei.predict(x.reshape(1, -1))
                return EI_from_ml_vl(ml.flat[0], vl.flat[0], bf)

            bx, ba = None, -1e20
            for _ in range(15):
                x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
                r  = minimize(lambda x: -acq(x), x0,
                              bounds=bounds, method='L-BFGS-B')
                if r.success and -r.fun > ba:
                    ba = -r.fun
                    bx = r.x
            if bx is None:
                bx = np.array([np.random.uniform(b[0], b[1]) for b in bounds])

            y1n, y2n, y3n = simulate_all(bx[0:1], bx[1:2], bx[2:3])
            X_ei = np.vstack((X_ei, bx.reshape(1, -1)))
            Y_ei = np.vstack((Y_ei, y3n))
            cost_c += COST_BOTH
            failed  = 0
            cost_log.append(cost_c)
            y3_log.append(float(Y_ei.min()))
        except Exception as e:
            failed += 1
            if failed >= max_retries:
                raise RuntimeError(
                    f"[EI] seed={seed} 连续 {max_retries} 次异常，最后一次: {e}") from e

    results['EI'] = {'bsf': _bsf_curve(cost_log, y3_log),
                     'final_best': float(Y_ei.min())}

    # ====================================================================
    # EIFN
    # ====================================================================
    eifn = EIFN_Optimizer(bounds)
    eifn.X1_data = X1_init.copy(); eifn.Y1_data = Y1_init.copy()
    eifn.X2_data = X2_init.copy(); eifn.Y2_data = Y2_init.copy()
    eifn.X3_full = X3_full_init.copy(); eifn.Y3_data = Y3_init.copy()
    eifn.best_y3 = float(Y3_init.min())
    cost_c   = 0.0
    failed   = 0
    cost_log = [0.0]
    y3_log   = [float(Y3_init.min())]

    while cost_c + COST_BOTH <= SEQUENTIAL_BUDGET:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                eifn.update_models()
                xn, _ = eifn.optimize_acquisition()
                eifn.add_observation(xn[0], xn[1], xn[2])
            cost_c += COST_BOTH
            failed  = 0
            cost_log.append(cost_c)
            y3_log.append(eifn.best_y3)
        except Exception as e:
            failed += 1
            if failed >= max_retries:
                raise RuntimeError(
                    f"[EIFN] seed={seed} 连续 {max_retries} 次异常，最后一次: {e}") from e

    results['EIFN'] = {'bsf': _bsf_curve(cost_log, y3_log),
                       'final_best': eifn.best_y3}

    # ====================================================================
    # EILGP（LGP + EI，每次全链采样）
    # ====================================================================
    X1_el = X1_init.copy(); Y1_el = Y1_init.copy()
    X2_el = X2_init.copy(); Y2_el = Y2_init.copy()
    X3_el = X3_full_init.copy(); Y3_el = Y3_init.copy()
    cost_c   = 0.0
    failed   = 0
    cost_log = [0.0]
    y3_log   = [float(Y3_init.min())]

    while cost_c + COST_BOTH <= SEQUENTIAL_BUDGET:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                m1 = fit_gp_f1(X1_el, Y1_el)
                m2 = fit_gp_f2(X2_el, Y2_el)
                m3 = fit_gp_f3(X3_el, Y3_el)
                lm = build_lgp_model(m1, m2, m3)
            bf   = Y3_el.min()
            bx, ba = None, -1e20
            for _ in range(15):
                x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
                r  = minimize(lambda x: -standard_EI(x, lm, bf),
                              x0, bounds=bounds, method='L-BFGS-B')
                if r.success and -r.fun > ba:
                    ba = -r.fun
                    bx = r.x
            if bx is None:
                bx = np.array([np.random.uniform(b[0], b[1]) for b in bounds])

            y1n, y2n, y3n = simulate_all(bx[0:1], bx[1:2], bx[2:3])
            X1_el = np.vstack((X1_el, bx[0:1].reshape(1, -1)))
            Y1_el = np.vstack((Y1_el, y1n))
            X2_el = np.vstack((X2_el, bx[1:2].reshape(1, -1)))
            Y2_el = np.vstack((Y2_el, y2n))
            X3_el = np.vstack((X3_el, np.hstack((y1n, y2n, bx[2:3].reshape(1, -1)))))
            Y3_el = np.vstack((Y3_el, y3n))
            cost_c += COST_BOTH
            failed  = 0
            cost_log.append(cost_c)
            y3_log.append(float(Y3_el.min()))
        except Exception as e:
            failed += 1
            if failed >= max_retries:
                raise RuntimeError(
                    f"[EILGP] seed={seed} 连续 {max_retries} 次异常，最后一次: {e}") from e

    results['EILGP'] = {'bsf': _bsf_curve(cost_log, y3_log),
                        'final_best': float(Y3_el.min())}

    # ====================================================================
    # CLEI（每次只在 layer1f1 / layer1f2 / layer2_reuse 三种节点采集函数间比较）
    # ====================================================================
    X1_cl = X1_init.copy(); Y1_cl = Y1_init.copy()
    X2_cl = X2_init.copy(); Y2_cl = Y2_init.copy()
    X3_cl = X3_full_init.copy(); Y3_cl = Y3_init.copy()
    cost_c   = 0.0
    failed   = 0
    cost_log = [0.0]
    y3_log   = [float(Y3_init.min())]

    while cost_c < SEQUENTIAL_BUDGET:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                m1 = fit_gp_f1(X1_cl, Y1_cl)
                m2 = fit_gp_f2(X2_cl, Y2_cl)
                m3 = fit_gp_f3(X3_cl, Y3_cl)
                lm = build_lgp_model(m1, m2, m3)

            bf = Y3_cl.min()

            strategy, opt_x, ei_vals = _clei_strategy(
                lm, m3, Y1_cl, Y2_cl, X1_cl, X2_cl, bf, bounds, n_restart=15)

            if strategy == 'layer1f1':
                cost_need = COST_LAYER1_P1
            elif strategy == 'layer1f2':
                cost_need = COST_LAYER1_P2
            else:  # 'layer2_reuse'
                cost_need = COST_LAYER2

            if cost_c + cost_need > SEQUENTIAL_BUDGET:
                break

            min_dist = 1e-4

            if strategy == 'layer1f1':
                # 新采 x1 = opt_x[0] = x_joint[0]
                x1_new = np.clip(float(opt_x[0]), bounds[0][0], bounds[0][1])
                xd1 = np.array([[x1_new]])
                if len(X1_cl) > 0 and \
                        np.min(np.linalg.norm(X1_cl - xd1, axis=1)) < min_dist:
                    x1_new += np.random.randn() * 0.01
                    x1_new = np.clip(x1_new, bounds[0][0], bounds[0][1])
                    xd1 = np.array([[x1_new]])
                y1n = f1(xd1)
                X1_cl = np.vstack((X1_cl, xd1))
                Y1_cl = np.vstack((Y1_cl, y1n))
                cost_c += COST_LAYER1_P1
                cost_log.append(cost_c)
                y3_log.append(float(Y3_cl.min()))   # best 未变

            elif strategy == 'layer1f2':
                # 新采 x2 = opt_x[1] = x_joint[1]
                x2_new = np.clip(float(opt_x[1]), bounds[1][0], bounds[1][1])
                xd2 = np.array([[x2_new]])
                if len(X2_cl) > 0 and \
                        np.min(np.linalg.norm(X2_cl - xd2, axis=1)) < min_dist:
                    x2_new += np.random.randn() * 0.01
                    x2_new = np.clip(x2_new, bounds[1][0], bounds[1][1])
                    xd2 = np.array([[x2_new]])
                y2n = f2(xd2)
                X2_cl = np.vstack((X2_cl, xd2))
                Y2_cl = np.vstack((Y2_cl, y2n))
                cost_c += COST_LAYER1_P2
                cost_log.append(cost_c)
                y3_log.append(float(Y3_cl.min()))   # best 未变

            else:  # 'layer2_reuse'
                # 复用已有 (y1, y2)，新采 x3
                y1s = float(opt_x[0])
                y2s = float(opt_x[1])
                x3s = float(opt_x[2])
                row = np.array([[y1s, y2s, x3s]])
                if len(X3_cl) > 0 and \
                        np.min(np.linalg.norm(X3_cl - row, axis=1)) < min_dist:
                    x3s += np.random.randn() * 0.1
                y3n = f3(np.array([[y1s]]), np.array([[y2s]]), np.array([[x3s]]))
                X3_cl = np.vstack((X3_cl, np.array([[y1s, y2s, x3s]])))
                Y3_cl = np.vstack((Y3_cl, y3n))
                cost_c += COST_LAYER2
                cost_log.append(cost_c)
                y3_log.append(float(Y3_cl.min()))

            failed = 0

        except Exception as e:
            failed += 1
            if failed >= max_retries:
                raise RuntimeError(
                    f"[CLEI] seed={seed} 连续 {max_retries} 次异常，最后一次: {e}") from e

    results['CLEI'] = {'bsf': _bsf_curve(cost_log, y3_log),
                       'final_best': float(Y3_cl.min())}
    return results


# =============================================================================
# 多次重复 & 汇总
# =============================================================================


def run_all_reps(n_reps=N_REPS, base_seed=BASE_SEED, save_file=SAVE_FILE,
                  max_attempts_per_rep=MAX_ATTEMPTS_PER_REP):
    """
    运行所有重复实验，保存结果，返回汇总统计。

    若某次重复（四种方法中任意一种）在拟合/优化过程中连续异常、重试用尽，
    则丢弃这一整次重复的所有结果，换一个新的随机种子重新完整跑一遍，
    直到成功（四种方法都正常跑满预算）为止，才计入第 i 次重复。最多尝试
    max_attempts_per_rep 次；如果全部尝试都失败，才放弃该次重复（记为 None）。
    """
    if os.path.exists(save_file):
        print(f"[Cache] 加载已有结果: {save_file}")
        with open(save_file, 'rb') as f:
            all_results = pickle.load(f)
    else:
        all_results = []

    start_rep = len(all_results)
    if start_rep < n_reps:
        print(f"[Run] 从第 {start_rep + 1} 次开始，共需完成 {n_reps} 次。")
        for i in range(start_rep, n_reps):
            res = None
            success = False
            for attempt in range(max_attempts_per_rep):
                # 第一次尝试用常规 seed；失败后换一个新 seed 重新完整跑，
                # 避免同一个 seed 反复触发完全相同的确定性失败。
                if attempt == 0:
                    trial_seed = base_seed + i
                else:
                    trial_seed = base_seed + n_reps * (attempt + 1) + i

                label = f"  Rep {i + 1:02d}/{n_reps}"
                if attempt > 0:
                    label += f"（第 {attempt + 1} 次重新开始）"
                print(f"{label}  seed={trial_seed}", end=' ... ', flush=True)

                try:
                    res = _run_one(trial_seed)
                    success = True
                    print(f"EI={res['EI']['final_best']:.4f}  "
                          f"EIFN={res['EIFN']['final_best']:.4f}  "
                          f"EILGP={res['EILGP']['final_best']:.4f}  "
                          f"CLEI={res['CLEI']['final_best']:.4f}")
                    break
                except Exception as e:
                    print(f"异常，丢弃本次重复的全部结果，重新开始: {e}")

            if not success:
                print(f"  [ERROR] Rep {i + 1} 连续 {max_attempts_per_rep} 次尝试均失败，"
                      f"放弃该次重复（记为 None）。")
                res = None

            all_results.append(res)

            if (i + 1) % 5 == 0:
                with open(save_file, 'wb') as f:
                    pickle.dump(all_results, f)
                print(f"  [Saved] {save_file}")
        with open(save_file, 'wb') as f:
            pickle.dump(all_results, f)
        print(f"[Saved] 全部结果已保存至 {save_file}")
    else:
        print(f"[Cache] 已有 {len(all_results)} 次结果，跳过运算。")
    return all_results


def summarize(all_results):
    valid = [r for r in all_results if r is not None]
    n     = len(valid)
    print(f"\n{'=' * 60}")
    print(f"汇总结果（有效重复次数: {n}/{len(all_results)}）")
    print(f"{'=' * 60}")
    print(f"\n{'方法':<12} {'均值':>10} {'标准差':>10} {'最好':>10} {'最差':>10}")
    print('-' * 54)

    mean_curves = {}
    for method in METHODS:
        finals    = [r[method]['final_best'] for r in valid]
        bsf_stack = np.array([r[method]['bsf'] for r in valid])
        mean_bsf  = np.nanmean(bsf_stack, axis=0)
        mean_curves[method] = mean_bsf
        mu  = np.mean(finals)
        std = np.std(finals)
        print(f"  {method:<10} {mu:>10.4f} {std:>10.4f} "
              f"{min(finals):>10.4f} {max(finals):>10.4f}")

    finals_mean = {m: np.mean([r[m]['final_best'] for r in valid])
                   for m in METHODS}
    ranked = sorted(finals_mean.items(), key=lambda kv: kv[1])
    print(f"\n排名（最终最优均值，越小越好）：")
    for rank, (m, v) in enumerate(ranked, 1):
        print(f"  #{rank}  {m:<10}  {v:.4f}")

    step = max(1, len(COST_AXIS) // 10)
    print(f"\n平均 best-so-far 曲线（代价步长 ~{COST_AXIS[step]:.0f}）：")
    header = f"{'Cost':>6}" + "".join(f"  {m:>10}" for m in METHODS)
    print(header)
    print('-' * (6 + 12 * len(METHODS)))
    for idx in range(0, len(COST_AXIS), step):
        row = f"{COST_AXIS[idx]:>6.0f}"
        for m in METHODS:
            val = mean_curves[m][idx]
            row += f"  {val:>10.4f}" if not np.isnan(val) else f"  {'NaN':>10}"
        print(row)
    print(f"\n{'=' * 60}")
    return mean_curves, finals_mean


# =============================================================================
# 主程序
# =============================================================================

if __name__ == '__main__':
    print("GP-Network 测试问题（并行两节点第一层）")
    print(f"  函数结构：x1→y1, x2→y2, (y1,y2,x3)→y3，最小化 y3")
    print(f"  预算={SEQUENTIAL_BUDGET}，代价：f1={COST_LAYER1_P1}, "
          f"f2={COST_LAYER1_P2}, f3={COST_LAYER2}, both={COST_BOTH}")
    print(f"  CLEI 每次只在 layer1f1 / layer1f2 / layer2_reuse 三种节点采集函数间比较（已移除 both 选项）")
    print(f"  任一方法异常重试用尽将丢弃整次重复并换新种子重新开始（上限 {MAX_ATTEMPTS_PER_REP} 次尝试）")
    print(f"  重复次数={N_REPS}，结果保存至 {SAVE_FILE}\n")

    all_results = run_all_reps(N_REPS, BASE_SEED, SAVE_FILE)
    mean_curves, finals_mean = summarize(all_results)
    print("\nDone.")