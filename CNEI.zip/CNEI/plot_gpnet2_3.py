"""
Convergence curve (left) + cost-to-match bar chart (right) for one network.

Usage:
    1. Modify RESULT_FILE / OUT_NAME below, then run:  python plot_convergence_cost.py
    2. Or override from command line:
       python plot_convergence_cost.py <result.pkl> <out_name>
"""
import sys
import pickle
import numpy as np
import matplotlib.pyplot as plt

# ===================== USER CONFIG =====================
# RESULT_FILE = 'gpnet2_100rep_results.pkl'   # 结果文件 2节点
RESULT_FILE = 'gpnet3_100rep_results.pkl'   # 结果文件 3节点
OUT_NAME    = 'gpnet3_convergence_cost'                          # 输出文件名前缀
BUDGET      = 500
CI          = 'sem95'   # 'sem95': mean ± 1.96*std/sqrt(n);  'std': mean ± std
# =======================================================

if len(sys.argv) > 1:
    RESULT_FILE = sys.argv[1]
if len(sys.argv) > 2:
    OUT_NAME = sys.argv[2]

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Times', 'DejaVu Serif'],
    'mathtext.fontset': 'stix',
    'font.size': 11,
    'axes.titlesize': 12,
})

METHODS = ['EI', 'EIFN', 'EILGP', 'CLEI']          # keys in the pkl
LABELS  = {'EI': 'EI', 'EIFN': 'EIFN', 'EILGP': 'EILGP', 'CLEI': 'CNEI'}
COLORS  = {'EI': '#5b9bd5', 'EIFN': '#ff7f0e', 'EILGP': '#4daf4a', 'CLEI': '#e41a1c'}
STYLES  = {'EI': ':', 'EIFN': '-.', 'EILGP': '--', 'CLEI': '-'}

with open(RESULT_FILE, 'rb') as fh:
    data = pickle.load(fh)

n_rep  = len(data)
curves = {m: np.array([rep[m]['bsf'] for rep in data]) for m in METHODS}
cost_axis = np.arange(curves['EI'].shape[1])

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 3.6))

# ---------- (a) convergence curves ----------
for m in METHODS:
    mean = curves[m].mean(axis=0)
    if CI == 'sem95':
        half = 1.96 * curves[m].std(axis=0) / np.sqrt(n_rep)
    else:
        half = curves[m].std(axis=0)
    ax1.plot(cost_axis, mean, STYLES[m], color=COLORS[m], lw=1.6, label=LABELS[m])
    ax1.fill_between(cost_axis, mean - half, mean + half, color=COLORS[m], alpha=0.15)
ax1.set_xlim(0, BUDGET)
ax1.set_xlabel('Cumulative Cost')
ax1.set_ylabel('Best value found (mean, 95% CI)')
ax1.set_title('(a) Convergence curves')
ax1.legend(frameon=True, framealpha=0.9)
ax1.grid(alpha=0.3, lw=0.5)

# ---------- (b) cost for CNEI to match competitors' final mean ----------
baselines = ['EI', 'EIFN', 'EILGP']
cnei_mean = curves['CLEI'].mean(axis=0)
match_costs = [int(np.argmax(cnei_mean <= curves[m].mean(axis=0)[-1])) for m in baselines]

y = np.arange(len(baselines))
ax2.barh(y, match_costs, height=0.55,
         color=[COLORS[m] for m in baselines], alpha=0.85)
ax2.axvline(BUDGET, color='crimson', ls='--', lw=1.2)
ax2.text(BUDGET - 8, -0.1, f'Budget = {BUDGET}', color='crimson',
         fontsize=9.5, va='top', ha='right')
for yi, c in zip(y, match_costs):
    ax2.text(c + 8, yi, f'{c}', va='center', fontsize=10)
ax2.set_yticks(y)
ax2.set_yticklabels([LABELS[m] for m in baselines])
ax2.invert_yaxis()
ax2.set_xlim(0, BUDGET + 60)
ax2.set_xlabel('Cumulative Cost required by CNEI')
ax2.set_title('(b) Cost to match final performance')
# keep all four spines (top and right included)
for side in ['top', 'right', 'bottom', 'left']:
    ax2.spines[side].set_visible(True)
ax2.tick_params(direction='in', top=False, right=False)

plt.tight_layout()
plt.savefig(f'{OUT_NAME}.pdf')
plt.savefig(f'{OUT_NAME}.png', dpi=200)
print('match costs:', dict(zip(baselines, match_costs)))
print(f'saved: {OUT_NAME}.pdf / {OUT_NAME}.png')