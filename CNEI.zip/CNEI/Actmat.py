# actmat_nd_with_eifn_runtime.py
# 支持任意维度的第一层Ackley函数，通过 DIM_LAYER1 参数控制维度
from dgpsi import dgp, kernel, combine, container, lgp, path, emulator, gp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from pyDOE2 import lhs
from scipy.optimize import minimize
from scipy.stats import norm
import time
import pandas as pd
import pickle
from datetime import datetime
import os

matplotlib.use('TkAgg')


# ------------------------
# ActMat函数定义 (任意维度版本)
# ------------------------

# ★ 唯一需要修改的维度参数 ★
DIM_LAYER1 = 1   # 第一层 Ackley 函数的输入维度，可设为 2, 4, 6, ...
# ------------------------
# 成本定义
# ------------------------
COST_LAYER1 = 1.0
COST_LAYER2 = 1.0
COST_BOTH = COST_LAYER1 + COST_LAYER2

# ------------------------
# 固定序贯预算（不包括初始样本）
# ------------------------
SEQUENTIAL_BUDGET = 100.0

def f1_ackley(x):
    """Ackley function: f1(x), 维度由 DIM_LAYER1 决定"""
    x = np.atleast_2d(x)
    d = x.shape[1]
    sum_sq = np.sum(x ** 2, axis=1)
    sum_cos = np.sum(np.cos(2 * np.pi * x), axis=1)
    term1 = -20 * np.exp(-0.2 * np.sqrt(sum_sq / d))
    term2 = -np.exp(sum_cos / d)
    result = term1 + term2 + 20 + np.exp(1)
    return result.reshape(-1, 1)


def f2_matyas(y1, x_prime):
    """Negated Matyas function: f2(y1, x')"""
    y1 = np.atleast_2d(y1)
    x_prime = np.atleast_2d(x_prime)
    result = 0.26 * (y1 ** 2 + x_prime ** 2) - 0.48 * y1 * x_prime
    return result

# ------------------------
# 随机种子设置
# ------------------------
BASE_SEED = 1

# ------------------------
# 停滞检测参数
# ------------------------
# STAGNATION_THRESHOLD = 1e-6
# EI_DIFFERENCE_THRESHOLD = 1e-6

STAGNATION_THRESHOLD = 1e-3
EI_DIFFERENCE_THRESHOLD = 0.01

# ------------------------
# EI采集函数
# ------------------------
def EI_from_ml_vl(ml, vl, best_f, xi=0.0):
    sigma = np.sqrt(np.maximum(vl, 1e-12))
    improvement = best_f - ml - xi
    u = improvement / sigma
    return improvement * norm.cdf(u) + sigma * norm.pdf(u)


def build_lgp_input_from_x(x):
    """构建LGP输入格式，x_prime 为第 DIM_LAYER1+1 个元素"""
    x = np.asarray(x).reshape(-1)
    X_global = x.reshape(1, -1)
    second_layer_external = [X_global[:, DIM_LAYER1:DIM_LAYER1 + 1]]  # x_prime 列
    return [X_global, second_layer_external]


# ========================
# EIFN Algorithm Implementation
# ========================
class EIFN_Optimizer:
    """EIFN optimizer using dgpsi's gp function"""

    def __init__(self, bounds, n_samples=50, n_restarts=15):
        self.bounds = bounds
        self.n_samples = n_samples
        self.n_restarts = n_restarts

        # Data storage for each node
        self.X1_data = None
        self.Y1_data = None
        self.X2_data = None
        self.Y2_data = None

        # GP models
        self.gp1 = None
        self.gp2 = None

        self.best_y2 = np.inf

    def add_observation(self, x_first_d, x_prime):
        """Add new observation by evaluating both layers"""
        # Evaluate f1
        y1 = f1_ackley(x_first_d.reshape(1, -1)).reshape(-1, 1)

        # Evaluate f2
        y2 = f2_matyas(y1, np.array([[x_prime]])).reshape(-1, 1)

        # Store data
        if self.X1_data is None:
            self.X1_data = x_first_d.reshape(1, -1)
            self.Y1_data = y1
            self.X2_data = np.hstack((y1, np.array([[x_prime]])))
            self.Y2_data = y2
        else:
            self.X1_data = np.vstack((self.X1_data, x_first_d.reshape(1, -1)))
            self.Y1_data = np.vstack((self.Y1_data, y1))
            self.X2_data = np.vstack((self.X2_data, np.hstack((y1, np.array([[x_prime]])))))
            self.Y2_data = np.vstack((self.Y2_data, y2))

        # Update best value
        self.best_y2 = min(self.best_y2, float(y2))

        return y2

    def update_models(self):
        """Update GP models for both nodes"""
        # Train GP for f1
        self.gp1 = gp(self.X1_data,
                      self.Y1_data,
                      kernel(length=np.ones(DIM_LAYER1), nugget=1e-6, name='matern2.5', scale_est=True))
        self.gp1.train()

        # Train GP for f2
        self.gp2 = gp(self.X2_data,
                      self.Y2_data,
                      kernel(length=np.ones(2), nugget=1e-6, name='matern2.5', scale_est=True))
        self.gp2.train()

    def sample_posterior(self, x, Z):
        """
        Sample from posterior using reparameterization trick
        x: [x1, x2, ..., x6, x_prime] (7-dimensional)
        Z: [Z1, Z2] (2-dimensional standard normal)
        """
        x_first_d = x[:DIM_LAYER1].reshape(1, -1)
        x_prime = x[DIM_LAYER1]

        # Sample from f1 posterior
        if self.gp1 is not None:
            mu1, var1 = self.gp1.predict(x_first_d)
            mu1 = mu1.flatten()[0]
            std1 = np.sqrt(max(var1.flatten()[0], 1e-12))
        else:
            mu1, std1 = 0.0, 1.0

        y1_sample = mu1 + std1 * Z[0]

        # Sample from f2 posterior conditioned on sampled y1
        x2_input = np.array([[y1_sample, x_prime]])
        if self.gp2 is not None:
            mu2, var2 = self.gp2.predict(x2_input)
            mu2 = mu2.flatten()[0]
            std2 = np.sqrt(max(var2.flatten()[0], 1e-12))
        else:
            mu2, std2 = 0.0, 1.0

        y2_sample = mu2 + std2 * Z[1]

        return y2_sample

    def compute_ei_saa(self, x, Z_samples):
        """Compute EI using Sample Average Approximation"""
        samples = []
        for m in range(len(Z_samples)):
            sample = self.sample_posterior(x, Z_samples[m])
            samples.append(sample)

        samples = np.array(samples)
        improvements = np.maximum(self.best_y2 - samples, 0)
        ei = np.mean(improvements)

        return ei

    def optimize_acquisition(self):
        """Optimize EIFN acquisition function"""
        Z_samples = np.random.randn(self.n_samples, 2)

        best_x = None
        best_ei = -np.inf

        for _ in range(self.n_restarts):
            x0 = np.array([np.random.uniform(b[0], b[1]) for b in self.bounds])

            def objective(x):
                return -self.compute_ei_saa(x, Z_samples)

            res = minimize(objective, x0=x0, bounds=self.bounds, method='L-BFGS-B')

            if res.success:
                ei = -res.fun
                if ei > best_ei:
                    best_ei = ei
                    best_x = res.x

        if best_x is None:
            best_x = np.array([np.random.uniform(b[0], b[1]) for b in self.bounds])

        return best_x, best_ei

# ------------------------
# 策略2: Layer2-reuse
# ------------------------
def optimize_layer2_with_sampled_y1(Y1_samples, m2_clei, best_f, x_prime_bounds, n_restart=15):
    """增强版：更多重启次数"""
    best_y1 = None
    best_x_prime = None
    best_ei_global = -1e20

    for y1_candidate in Y1_samples.flatten():
        best_x_prime_for_y1 = None
        best_ei_for_y1 = -1e20

        for _ in range(n_restart):
            x_prime_init = np.random.uniform(x_prime_bounds[0], x_prime_bounds[1])

            def objective_x_prime(x_prime_val):
                x_prime_input = np.array([[y1_candidate, x_prime_val[0]]])
                ml, vl = m2_clei.predict(x_prime_input)
                ei = EI_from_ml_vl(ml.flatten()[0], vl.flatten()[0], best_f)
                return -ei

            res = minimize(objective_x_prime, x0=[x_prime_init], bounds=[x_prime_bounds], method='L-BFGS-B')

            if res.success:
                x_prime_opt = res.x[0]
                x_prime_input = np.array([[y1_candidate, x_prime_opt]])
                ml, vl = m2_clei.predict(x_prime_input)
                ei_val = EI_from_ml_vl(ml.flatten()[0], vl.flatten()[0], best_f)

                if ei_val > best_ei_for_y1:
                    best_ei_for_y1 = ei_val
                    best_x_prime_for_y1 = x_prime_opt

        if best_ei_for_y1 > best_ei_global:
            best_ei_global = best_ei_for_y1
            best_y1 = y1_candidate
            best_x_prime = best_x_prime_for_y1

    return best_y1, best_x_prime, best_ei_global


# ------------------------
# 策略3: Both
# ------------------------
def standard_EI(x, model_lgp, best_f):
    x_input = build_lgp_input_from_x(x)
    ml, vl = model_lgp.predict(x_input)
    return EI_from_ml_vl(ml[0][0, 0], vl[0][0, 0], best_f)


def optimize_both_strategy_ei(model_lgp, best_f, bounds, n_restart=15):
    """增强版：更多重启次数"""
    best_x = None
    best_ei = -1e20

    for _ in range(n_restart):
        x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])

        def objective(x):
            return -standard_EI(x, model_lgp, best_f)

        res = minimize(objective, x0=x0, bounds=bounds, method='L-BFGS-B')

        if res.success:
            ei = -res.fun
            if ei > best_ei:
                best_ei = ei
                best_x = res.x

    if best_x is None:
        x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
        best_ei = standard_EI(x0, model_lgp, best_f)
        best_x = x0

    return best_x, best_ei


# ------------------------
# 停滞检测
# ------------------------
def check_stagnation(ei_history, threshold=STAGNATION_THRESHOLD):
    if len(ei_history) < 2:
        return False
    ei_diff = abs(ei_history[-1] - ei_history[-2])
    return ei_diff < threshold


def check_ei_convergence(ei_layer1, ei_layer2, threshold=EI_DIFFERENCE_THRESHOLD):
    return abs(ei_layer1 - ei_layer2) < threshold


# ------------------------
# 优化采集函数
# ------------------------
def optimize_clei_strategy_with_stagnation(model_lgp, m2_clei, Y1_samples, X2_data, Y2_data,
                                            best_f, bounds, ei_layer1_history,
                                            ei_layer2_history, last_strategy, n_restart=15):

    # 优化Layer2-reuse
    y1_reuse, x_prime_reuse, ei_layer2_reuse = optimize_layer2_with_sampled_y1(
        Y1_samples, m2_clei, best_f, bounds[DIM_LAYER1], n_restart=n_restart
    )

    # 优化Both
    x_both_opt, ei_both = optimize_both_strategy_ei(model_lgp, best_f, bounds, n_restart=n_restart)

    # 优化Layer1
    best_x_first_d = x_both_opt[:DIM_LAYER1]
    best_x_prime   = x_both_opt[DIM_LAYER1]
    best_ei_layer1 = ei_both
    # 计算性价比
    ei_per_cost_layer1 = (best_ei_layer1 - ei_layer2_reuse) / COST_LAYER1
    ei_per_cost_layer2_reuse = ei_layer2_reuse / COST_LAYER2
    ei_per_cost_both = ei_both / COST_BOTH

    # 检测停滞
    layer1_stagnant = check_stagnation(ei_layer1_history)
    layer2_stagnant = check_stagnation(ei_layer2_history)
    ei_converged = check_ei_convergence(best_ei_layer1, ei_layer2_reuse)

    stagnation_override = False

    # 停滞处理逻辑
    if ei_converged:
        strategy_name = 'both'
        opt_x = x_both_opt
        stagnation_override = True
    elif last_strategy == 'layer1' and layer1_stagnant:
        strategy_name = 'both'
        opt_x = x_both_opt
        stagnation_override = True
    elif last_strategy == 'layer2_reuse' and layer2_stagnant:
        strategy_name = 'both'
        opt_x = x_both_opt
        stagnation_override = True
    else:
        strategies = {
            'layer1':       (ei_per_cost_layer1,       (best_x_first_d, best_x_prime)),
            'layer2_reuse': (ei_per_cost_layer2_reuse, (y1_reuse, x_prime_reuse)),
            'both':         (ei_per_cost_both,          x_both_opt)
        }
        best_strategy = max(strategies.items(), key=lambda item: item[1][0])
        strategy_name = best_strategy[0]
        opt_x = best_strategy[1][1]

    ei_values = (best_ei_layer1, ei_layer2_reuse, ei_both)

    if strategy_name == 'layer1':
        ei_per_cost = ei_per_cost_layer1
    elif strategy_name == 'layer2_reuse':
        ei_per_cost = ei_per_cost_layer2_reuse
    else:
        ei_per_cost = ei_per_cost_both

    return strategy_name, opt_x, ei_per_cost, ei_values, stagnation_override

# ------------------------
# 单次运行函数（6D版本+运行时间）
# ------------------------
def run_single_experiment(seed=42, sequential_budget=SEQUENTIAL_BUDGET, dim=DIM_LAYER1, verbose=True):
    np.random.seed(seed)

    if verbose:
        print(f"\n{'=' * 80}")
        print(f"Running Experiment - ActMat ({dim}D) - Improved Layer1 with EIFN")
        print(f"Seed: {seed}")
        print(f"Sequential Budget: {sequential_budget}")
        print(f"{'=' * 80}\n")

    bounds = [(-2, 2)] * dim + [(-10, 10)]  # dim维输入 + 1维x_prime
    nx = 2 * (dim + 1+1)                       # 初始样本数 = 2(d+1)

    # 初始数据
    unit_samples = lhs(len(bounds), samples=nx, criterion='maximin')
    X = np.array([low + (high - low) * unit_samples[:, i]
                  for i, (low, high) in enumerate(bounds)]).T

    X_first_d = X[:, :dim]
    Y1 = f1_ackley(X_first_d).reshape(-1, 1)
    x_prime = X[:, dim].reshape(-1, 1)
    X2_full = np.hstack((Y1, x_prime))
    Y2 = f2_matyas(Y1, x_prime).reshape(-1, 1)
    initial_best_y2 = float(Y2.min())

    # CLEI方法
    X1_clei = X_first_d.copy()
    Y1_clei = Y1.copy()
    X2_clei = X2_full.copy()
    Y2_clei = Y2.copy()

    # EILGP方法
    X1_eilgp = X_first_d.copy()
    Y1_eilgp = Y1.copy()
    X2_eilgp = X2_full.copy()
    Y2_eilgp = Y2.copy()

    # EI (黑箱GP)
    X_ei = X.copy()
    Y_ei = Y2.copy()

    # EIFN
    eifn_optimizer = EIFN_Optimizer(bounds, n_samples=50, n_restarts=15)
    for i in range(len(X)):
        eifn_optimizer.X1_data = X_first_d[:i + 1] if i == 0 else np.vstack(
            (eifn_optimizer.X1_data, X_first_d[i:i + 1]))
        eifn_optimizer.Y1_data = Y1[:i + 1] if i == 0 else np.vstack((eifn_optimizer.Y1_data, Y1[i:i + 1]))
        eifn_optimizer.X2_data = X2_full[:i + 1] if i == 0 else np.vstack((eifn_optimizer.X2_data, X2_full[i:i + 1]))
        eifn_optimizer.Y2_data = Y2[:i + 1] if i == 0 else np.vstack((eifn_optimizer.Y2_data, Y2[i:i + 1]))
    eifn_optimizer.best_y2 = initial_best_y2

    # 记录
    y_best_clei = []
    y_best_eilgp = []
    y_best_ei = []
    y_best_eifn = []

    cumulative_cost_clei = 0.0
    cumulative_cost_eilgp = 0.0
    cumulative_cost_ei = 0.0
    cumulative_cost_eifn = 0.0

    costs_clei = []
    costs_eilgp = []
    costs_ei = []
    costs_eifn = []

    strategy_history = []
    stagnation_count = 0

    ei_layer1_history = []
    ei_layer2_history = []
    last_strategy = None

    iteration = 0
    max_retries = 5

    # === CLEI方法 ===
    if verbose:
        print("Starting CLEI optimization...")
    start_time_clei = time.time()
    failed_iterations = 0

    while cumulative_cost_clei < sequential_budget:
        try:
            m1_clei = gp(X1_clei, Y1_clei,
                          kernel(length=np.ones(dim), nugget=1e-6, name='matern2.5', scale_est=True))
            m1_clei.train()

            m2_clei = gp(X2_clei, Y2_clei,
                          kernel(length=np.ones(2), nugget=1e-6, name='matern2.5', scale_est=True,
                                 input_dim=np.array([0]), connect=np.array([1])))
            m2_clei.train()

            c1_clei = container(m1_clei.export(), local_input_idx=np.arange(dim))
            c2_clei = container(m2_clei.export(), local_input_idx=np.array([0]))
            struc_clei = [[c1_clei], [c2_clei]]
            lm_clei = lgp(struc_clei, N=10)

            best_f_clei = Y2_clei.min()

            strategy, x_new, ei_per_cost, ei_values, stagnation_flag = optimize_clei_strategy_with_stagnation(
                lm_clei, m2_clei, Y1_clei, X2_clei, Y2_clei, best_f_clei, bounds,
                ei_layer1_history, ei_layer2_history, last_strategy, n_restart=15
            )

            ei_layer1, ei_layer2_reuse, ei_both = ei_values

            if strategy == 'layer1':
                cost_needed = COST_LAYER1
            elif strategy == 'layer2_reuse':
                cost_needed = COST_LAYER2
            else:
                cost_needed = COST_BOTH

            if cumulative_cost_clei + cost_needed > sequential_budget:
                break

            min_distance_threshold = 1e-4
            point_too_close = False

            if strategy == 'layer1':
                x_first_d_new, x_prime_new = x_new
                distances = np.linalg.norm(X1_clei - x_first_d_new.reshape(1, -1), axis=1)
                if np.min(distances) < min_distance_threshold:
                    point_too_close = True

            elif strategy == 'layer2_reuse':
                y1_selected, x_prime_new = x_new
                X2_row = np.array([[y1_selected, x_prime_new]])
                distances = np.linalg.norm(X2_clei - X2_row, axis=1)
                if np.min(distances) < min_distance_threshold:
                    point_too_close = True

            else:
                x_first_d_new, x_prime_new = x_new[:dim], x_new[dim]
                distances_x1 = np.linalg.norm(X1_clei - x_first_d_new.reshape(1, -1), axis=1)
                if np.min(distances_x1) < min_distance_threshold:
                    point_too_close = True

            if point_too_close:
                if verbose:
                    print(f"  WARNING: New point too close, adding perturbation")
                if strategy == 'layer1':
                    x_first_d_new = np.array(x_first_d_new) + np.random.randn(dim) * 0.01
                    x_prime_new += np.random.randn() * 0.1
                elif strategy == 'layer2_reuse':
                    x_prime_new += np.random.randn() * 0.1
                else:
                    x_first_d_new += np.random.randn(dim) * 0.01
                    x_prime_new += np.random.randn() * 0.1

            strategy_history.append(strategy)
            if stagnation_flag:
                stagnation_count += 1

            ei_layer1_history.append(ei_layer1)
            ei_layer2_history.append(ei_layer2_reuse)
            last_strategy = strategy

            if strategy == 'layer1':
                y1_new = f1_ackley(x_first_d_new.reshape(1, -1)).reshape(-1, 1)
                X1_clei = np.vstack((X1_clei, x_first_d_new.reshape(1, -1)))
                Y1_clei = np.vstack((Y1_clei, y1_new))
                cumulative_cost_clei += COST_LAYER1

            elif strategy == 'layer2_reuse':
                y2_new = f2_matyas(np.array([[y1_selected]]), np.array([[x_prime_new]])).reshape(-1, 1)
                X2_clei = np.vstack((X2_clei, np.array([[y1_selected, x_prime_new]])))
                Y2_clei = np.vstack((Y2_clei, y2_new))
                cumulative_cost_clei += COST_LAYER2

            else:
                y1_new = f1_ackley(x_first_d_new.reshape(1, -1)).reshape(-1, 1)
                X2_row = np.hstack((y1_new, np.array([[x_prime_new]])))
                y2_new = f2_matyas(y1_new, np.array([[x_prime_new]])).reshape(-1, 1)
                X1_clei = np.vstack((X1_clei, x_first_d_new.reshape(1, -1)))
                Y1_clei = np.vstack((Y1_clei, y1_new))
                X2_clei = np.vstack((X2_clei, X2_row))
                Y2_clei = np.vstack((Y2_clei, y2_new))
                cumulative_cost_clei += COST_BOTH

            y_best_clei.append(Y2_clei.min())
            costs_clei.append(cumulative_cost_clei)

            if verbose and iteration % 5 == 0:
                print(
                    f"  Iter {iteration}: Strategy={strategy}, Best Y2={Y2_clei.min():.6f}, Cost={cumulative_cost_clei:.1f}")

            iteration += 1
            failed_iterations = 0

        except (np.linalg.LinAlgError, RuntimeWarning) as e:
            failed_iterations += 1
            if verbose:
                print(f"  WARNING: Iteration {iteration} failed, retrying... ({failed_iterations}/{max_retries})")
            if failed_iterations >= max_retries:
                if verbose:
                    print(f"  ERROR: Max retries reached")
                break
            continue

    clei_time = time.time() - start_time_clei
    if verbose:
        print(f"CLEI completed: {iteration} iterations, {clei_time:.2f}s\n")

    # === EILGP ===
    if verbose:
        print("Starting EILGP optimization...")
    start_time_eilgp = time.time()
    iter_eilgp = 0
    failed_eilgp = 0

    while cumulative_cost_eilgp < sequential_budget:
        if cumulative_cost_eilgp + COST_BOTH > sequential_budget:
            break

        try:
            m1_eilgp = gp(X1_eilgp, Y1_eilgp,
                        kernel(length=np.ones(dim), nugget=1e-6, name='matern2.5', scale_est=True))
            m1_eilgp.train()
            c1_eilgp = container(m1_eilgp.export(), local_input_idx=np.arange(dim))

            m2_eilgp = gp(X2_eilgp, Y2_eilgp,
                        kernel(length=np.ones(2), nugget=1e-6, name='matern2.5', scale_est=True,
                               input_dim=np.array([0]), connect=np.array([1])))
            m2_eilgp.train()
            c2_eilgp = container(m2_eilgp.export(), local_input_idx=np.array([0]))

            struc_eilgp = [[c1_eilgp], [c2_eilgp]]
            lm_eilgp = lgp(struc_eilgp, N=10)
            best_f_eilgp = Y2_eilgp.min()

            def objective_eilgp(x):
                return -standard_EI(x, lm_eilgp, best_f_eilgp)

            best_x_eilgp = None
            best_acq_eilgp = -1e20
            for _ in range(15):
                x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
                res = minimize(objective_eilgp, x0=x0, bounds=bounds, method='L-BFGS-B')
                if res.success:
                    acq_val = -res.fun
                    if acq_val > best_acq_eilgp:
                        best_acq_eilgp = acq_val
                        best_x_eilgp = res.x

            if best_x_eilgp is None:
                best_x_eilgp = np.array([np.random.uniform(b[0], b[1]) for b in bounds])

            x_first_d_eilgp, x_prime_eilgp = best_x_eilgp[:dim], best_x_eilgp[dim]
            y1_eilgp = f1_ackley(x_first_d_eilgp.reshape(1, -1)).reshape(-1, 1)
            X2_row_eilgp = np.hstack((y1_eilgp, np.array([[x_prime_eilgp]])))
            y2_eilgp = f2_matyas(y1_eilgp, np.array([[x_prime_eilgp]])).reshape(-1, 1)

            X1_eilgp = np.vstack((X1_eilgp, x_first_d_eilgp.reshape(1, -1)))
            Y1_eilgp = np.vstack((Y1_eilgp, y1_eilgp))
            X2_eilgp = np.vstack((X2_eilgp, X2_row_eilgp))
            Y2_eilgp = np.vstack((Y2_eilgp, y2_eilgp))

            cumulative_cost_eilgp += COST_BOTH

            y_best_eilgp.append(Y2_eilgp.min())
            costs_eilgp.append(cumulative_cost_eilgp)

            if verbose and iter_eilgp % 5 == 0:
                print(f"  Iter {iter_eilgp}: Best Y2={Y2_eilgp.min():.6f}, Cost={cumulative_cost_eilgp:.1f}")

            iter_eilgp += 1
            failed_eilgp = 0

        except (np.linalg.LinAlgError, RuntimeWarning) as e:
            failed_eilgp += 1
            if verbose:
                print(f"  WARNING: EILGP iteration {iter_eilgp} failed, retrying... ({failed_eilgp}/{max_retries})")
            if failed_eilgp >= max_retries:
                if verbose:
                    print(f"  ERROR: Max retries reached for EILGP")
                break
            continue

    eilgp_time = time.time() - start_time_eilgp
    if verbose:
        print(f"EILGP completed: {iter_eilgp} iterations, {eilgp_time:.2f}s\n")

    # === EI (黑箱GP) ===
    if verbose:
        print("Starting EI optimization...")
    start_time_ei = time.time()
    iter_ei = 0
    failed_ei = 0

    while cumulative_cost_ei < sequential_budget:
        if cumulative_cost_ei + COST_BOTH > sequential_budget:
            break

        try:
            m_ei = gp(X_ei, Y_ei,
                            kernel(length=np.ones(dim + 1), nugget=1e-6, name='matern2.5', scale_est=True))
            m_ei.train()

            best_f_ei = Y_ei.min()

            def ei_acquisition(x):
                x_input = x.reshape(1, -1)
                ml, vl = m_ei.predict(x_input)
                return EI_from_ml_vl(ml.flatten()[0], vl.flatten()[0], best_f_ei)

            def objective_ei(x):
                return -ei_acquisition(x)

            best_x_ei = None
            best_acq_ei = -1e20
            for _ in range(15):
                x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
                res = minimize(objective_ei, x0=x0, bounds=bounds, method='L-BFGS-B')
                if res.success:
                    acq_val = -res.fun
                    if acq_val > best_acq_ei:
                        best_acq_ei = acq_val
                        best_x_ei = res.x

            if best_x_ei is None:
                best_x_ei = np.array([np.random.uniform(b[0], b[1]) for b in bounds])

            x_first_d_ei, x_prime_ei = best_x_ei[:dim], best_x_ei[dim]
            y1_ei = f1_ackley(x_first_d_ei.reshape(1, -1)).reshape(-1, 1)
            y2_ei = f2_matyas(y1_ei, np.array([[x_prime_ei]])).reshape(-1, 1)

            X_ei = np.vstack((X_ei, best_x_ei.reshape(1, -1)))
            Y_ei = np.vstack((Y_ei, y2_ei))

            cumulative_cost_ei += COST_BOTH

            y_best_ei.append(Y_ei.min())
            costs_ei.append(cumulative_cost_ei)

            if verbose and iter_ei % 5 == 0:
                print(f"  Iter {iter_ei}: Best Y2={Y_ei.min():.6f}, Cost={cumulative_cost_ei:.1f}")

            iter_ei += 1
            failed_ei = 0

        except (np.linalg.LinAlgError, RuntimeWarning) as e:
            failed_ei += 1
            if verbose:
                print(f"  WARNING: EI iteration {iter_ei} failed, retrying... ({failed_ei}/{max_retries})")
            if failed_ei >= max_retries:
                if verbose:
                    print(f"  ERROR: Max retries reached for EI")
                break
            continue

    ei_time = time.time() - start_time_ei
    if verbose:
        print(f"EI completed: {iter_ei} iterations, {ei_time:.2f}s\n")

    # === EIFN ===
    if verbose:
        print("Starting EIFN optimization...")
    start_time_eifn = time.time()
    iter_eifn = 0
    failed_eifn = 0

    while cumulative_cost_eifn < sequential_budget:
        if cumulative_cost_eifn + COST_BOTH > sequential_budget:
            break

        try:
            eifn_optimizer.update_models()
            x_next, ei_val = eifn_optimizer.optimize_acquisition()

            x_first_d_eifn = x_next[:dim]
            x_prime_eifn = x_next[dim]
            y2_new = eifn_optimizer.add_observation(x_first_d_eifn, x_prime_eifn)

            cumulative_cost_eifn += COST_BOTH

            y_best_eifn.append(eifn_optimizer.best_y2)
            costs_eifn.append(cumulative_cost_eifn)

            if verbose and iter_eifn % 5 == 0:
                print(f"  Iter {iter_eifn}: Best Y2={eifn_optimizer.best_y2:.6f}, Cost={cumulative_cost_eifn:.1f}")

            iter_eifn += 1
            failed_eifn = 0

        except (np.linalg.LinAlgError, RuntimeWarning) as e:
            failed_eifn += 1
            if verbose:
                print(f"  WARNING: EIFN iteration {iter_eifn} failed, retrying... ({failed_eifn}/{max_retries})")
            if failed_eifn >= max_retries:
                if verbose:
                    print(f"  ERROR: Max retries reached for EIFN")
                break
            continue

    eifn_time = time.time() - start_time_eifn
    if verbose:
        print(f"EIFN completed: {iter_eifn} iterations, {eifn_time:.2f}s\n")

    # 统计策略使用
    layer1_count = strategy_history.count('layer1')
    layer2_reuse_count = strategy_history.count('layer2_reuse')
    both_count = strategy_history.count('both')

    # 打印结果
    if verbose:
        print(f"\n{'=' * 80}")
        print(f"RESULTS SUMMARY ({dim}D Version with EIFN)")
        print(f"{'=' * 80}")
        print(f"\nFinal Best Y2:")
        print(f"  CLEI:   {y_best_clei[-1] if y_best_clei else Y2_clei.min():.6f}")
        print(f"  EILGP:  {y_best_eilgp[-1] if y_best_eilgp else Y2_eilgp.min():.6f}")
        print(f"  EI:     {y_best_ei[-1] if y_best_ei else Y_ei.min():.6f}")
        print(f"  EIFN:   {y_best_eifn[-1] if y_best_eifn else initial_best_y2:.6f}")

        print(f"\nRuntime (seconds):")
        print(f"  CLEI:   {clei_time:.2f}s")
        print(f"  EILGP:  {eilgp_time:.2f}s")
        print(f"  EI:     {ei_time:.2f}s")
        print(f"  EIFN:   {eifn_time:.2f}s")

        print(f"\nTotal Cost Used:")
        print(f"  CLEI:   {cumulative_cost_clei:.1f}")
        print(f"  EILGP:  {cumulative_cost_eilgp:.1f}")
        print(f"  EI:     {cumulative_cost_ei:.1f}")
        print(f"  EIFN:   {cumulative_cost_eifn:.1f}")

        print(f"\nNumber of Iterations:")
        print(f"  CLEI:   {len(y_best_clei)}")
        print(f"  EILGP:  {len(y_best_eilgp)}")
        print(f"  EI:     {len(y_best_ei)}")
        print(f"  EIFN:   {len(y_best_eifn)}")

        print(f"\nStrategy Usage (CLEI):")
        total_strategies = layer1_count + layer2_reuse_count + both_count
        if total_strategies > 0:
            print(f"  Layer1:       {layer1_count} ({layer1_count / total_strategies * 100:.1f}%)")
            print(f"  Layer2-reuse: {layer2_reuse_count} ({layer2_reuse_count / total_strategies * 100:.1f}%)")
            print(f"  Both:         {both_count} ({both_count / total_strategies * 100:.1f}%)")

        print(f"\nStagnation Events: {stagnation_count}")
        print(f"{'=' * 80}\n")

    return {
        'y_best_clei': y_best_clei,
        'y_best_eilgp': y_best_eilgp,
        'y_best_ei': y_best_ei,
        'y_best_eifn': y_best_eifn,
        'costs_clei': costs_clei,
        'costs_eilgp': costs_eilgp,
        'costs_ei': costs_ei,
        'costs_eifn': costs_eifn,
        'runtime_clei': clei_time,
        'runtime_eilgp': eilgp_time,
        'runtime_ei': ei_time,
        'runtime_eifn': eifn_time,
        'strategy_history': strategy_history,
        'seed': seed,
        'dim': dim,
        'initial_best_y2': initial_best_y2,
        'n_iterations_clei': len(y_best_clei),
        'n_iterations_eilgp': len(y_best_eilgp),
        'n_iterations_ei': len(y_best_ei),
        'n_iterations_eifn': len(y_best_eifn)
    }


# ------------------------
# 保存结果函数
# ------------------------
def save_results(all_results, output_dir='results'):
    """
    保存实验结果到文件：
    1. 四个算法各一个Excel：
       - 第1列: 累计资源消耗（0, 1, 2, ..., SEQUENTIAL_BUDGET，步长为1）
       - 第2列起: 每次实验对应算法在该资源量下的当前最优值（step-wise插值）
    2. 一个运行时间Excel：
       - 行：每次实验；列：四个算法的运行时间（秒）
    """
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # 资源网格：0, 1, 2, ..., SEQUENTIAL_BUDGET（整数步长）
    resource_grid = np.arange(0, int(SEQUENTIAL_BUDGET) + 1, 1)

    def interpolate_to_grid(costs, y_bests, initial_best, grid):
        """
        将 (costs, y_bests) 的阶梯曲线插值到 grid 上。
        对于 grid 中每个资源值 g：
          - 若 g < 第一个 cost，则当前最优 = initial_best（初始样本对应的最优）
          - 否则取所有 cost <= g 中最大的那个对应的 y_best
        """
        values = []
        for g in grid:
            valid = [(c, y) for c, y in zip(costs, y_bests) if c <= g]
            if valid:
                # 取资源消耗不超过 g 的最后一个最优值
                values.append(valid[-1][1])
            else:
                # 尚未花费任何序贯资源，使用初始最优值
                values.append(initial_best)
        return values

    # ----------------------------------------------------------------
    # 1. 四个算法各自的 Excel
    # ----------------------------------------------------------------
    algo_cfg = [
        ('CLEI',  'costs_clei',  'y_best_clei',  'runtime_clei'),
        ('EILGP', 'costs_eilgp', 'y_best_eilgp', 'runtime_eilgp'),
        ('EI',    'costs_ei',    'y_best_ei',     'runtime_ei'),
        ('EIFN',  'costs_eifn',  'y_best_eifn',   'runtime_eifn'),
    ]

    for algo_name, costs_key, best_key, _ in algo_cfg:
        data = {'cumulative_cost': resource_grid}

        for exp_id, result in enumerate(all_results):
            costs  = result[costs_key]
            bests  = result[best_key]
            init_b = result['initial_best_y2']

            col = interpolate_to_grid(costs, bests, init_b, resource_grid)
            data[f'exp_{exp_id + 1}_seed_{result["seed"]}'] = col

        df = pd.DataFrame(data)
        fname = f'{output_dir}/{algo_name}_convergence_{timestamp}.xlsx'
        df.to_excel(fname, index=False)
        print(f"已保存: {fname}")

    # ----------------------------------------------------------------
    # 2. 运行时间 Excel
    # ----------------------------------------------------------------
    runtime_data = {
        'experiment_id': [],
        'seed':          [],
        'CLEI_time_s':   [],
        'EILGP_time_s':  [],
        'EI_time_s':     [],
        'EIFN_time_s':   [],
    }

    for exp_id, result in enumerate(all_results):
        runtime_data['experiment_id'].append(exp_id + 1)
        runtime_data['seed'].append(result['seed'])
        runtime_data['CLEI_time_s'].append(result['runtime_clei'])
        runtime_data['EILGP_time_s'].append(result['runtime_eilgp'])
        runtime_data['EI_time_s'].append(result['runtime_ei'])
        runtime_data['EIFN_time_s'].append(result['runtime_eifn'])

    runtime_df = pd.DataFrame(runtime_data)
    runtime_fname = f'{output_dir}/runtime_{timestamp}.xlsx'
    runtime_df.to_excel(runtime_fname, index=False)
    print(f"已保存: {runtime_fname}")

    # ----------------------------------------------------------------
    # 3. 保存原始结果对象（便于后续分析）
    # ----------------------------------------------------------------
    pkl_fname = f'{output_dir}/all_results_{timestamp}.pkl'
    with open(pkl_fname, 'wb') as f:
        pickle.dump(all_results, f)
    print(f"已保存: {pkl_fname}")

    print(f"\n结果已保存到 {output_dir}/ 目录")
    print(f"- 各算法收敛数据: CLEI/EILGP/EI/EIFN_convergence_*.xlsx")
    print(f"- 运行时间汇总:   runtime_*.xlsx")
    print(f"- 原始数据:       all_results_*.pkl")

    return runtime_df


# ------------------------
# 绘制收敛图函数（阶梯状，调整顺序）
# ------------------------
def plot_convergence_curves(all_results, output_dir='results', show_individual=False):
    """绘制算法收敛曲线（阶梯状）"""
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    max_cost = SEQUENTIAL_BUDGET

    # 为了绘制阶梯图，我们需要使用原始的cost和best值
    plt.figure(figsize=(12, 7))

    # 收集所有实验的数据用于计算均值和标准差
    def collect_curves(results_key, costs_key):
        all_costs = []
        all_values = []
        for result in all_results:
            if result[results_key] and result[costs_key]:
                all_costs.append(result[costs_key])
                all_values.append(result[results_key])
        return all_costs, all_values

    def plot_stepwise_curve(all_costs, all_values, color, label, linestyle='-', linewidth=2.5):
        """绘制阶梯状曲线及其标准差带"""
        # 找到所有唯一的cost点
        all_cost_points = set()
        for costs in all_costs:
            all_cost_points.update(costs)
        cost_points = sorted(list(all_cost_points))

        # 为每个cost点插值所有实验的值
        interpolated_values = []
        for costs, values in zip(all_costs, all_values):
            interp_vals = []
            for cp in cost_points:
                # 找到小于等于cp的最大cost对应的值
                valid_indices = [i for i, c in enumerate(costs) if c <= cp]
                if valid_indices:
                    interp_vals.append(values[valid_indices[-1]])
                else:
                    # 如果没有点，使用初始值
                    interp_vals.append(all_results[0]['initial_best_y2'])
            interpolated_values.append(interp_vals)

        interpolated_values = np.array(interpolated_values)
        mean_values = np.mean(interpolated_values, axis=0)
        std_values = np.std(interpolated_values, axis=0)

        # 绘制阶梯图
        plt.step(cost_points, mean_values, where='post', color=color, linewidth=linewidth,
                 label=label, alpha=0.9, linestyle=linestyle)
        plt.fill_between(cost_points,
                         mean_values - std_values,
                         mean_values + std_values,
                         color=color, alpha=0.2, step='post')

    # 按照指定顺序绘制：CLEI, EILGP, EIFN, EI

    # 1. CLEI (Ours)
    costs_clei, values_clei = collect_curves('y_best_clei', 'costs_clei')
    plot_stepwise_curve(costs_clei, values_clei, 'blue', 'CLEI', '-', 2.5)

    # 2. EILGP
    costs_eilgp, values_eilgp = collect_curves('y_best_eilgp', 'costs_eilgp')
    plot_stepwise_curve(costs_eilgp, values_eilgp, 'red', 'EILGP', '--', 2.5)

    # 3. EIFN
    costs_eifn, values_eifn = collect_curves('y_best_eifn', 'costs_eifn')
    plot_stepwise_curve(costs_eifn, values_eifn, 'magenta', 'EIFN', '-.', 2.5)

    # 4. EI
    costs_ei, values_ei = collect_curves('y_best_ei', 'costs_ei')
    plot_stepwise_curve(costs_ei, values_ei, 'green', 'EI', ':', 2.5)

    plt.xlabel('Cumulative Cost', fontsize=14, fontweight='bold')
    plt.ylabel('Best Objective Value', fontsize=14, fontweight='bold')
    plt.title(f'Convergence Comparison on ActMat Function ({DIM_LAYER1}D)', fontsize=16, fontweight='bold')
    plt.legend(fontsize=12, loc='best', framealpha=0.9)
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.xlim(0, max_cost)
    plt.tight_layout()
    plt.savefig(f'{output_dir}/convergence_comparison_{timestamp}.png', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_dir}/convergence_comparison_{timestamp}.pdf', bbox_inches='tight')
    print(f"\n收敛图已保存: {output_dir}/convergence_comparison_{timestamp}.png")

    plt.show()


# ------------------------
# 绘制箱线图函数（调整顺序）
# ------------------------
def plot_final_boxplot(all_results, output_dir='results'):
    """绘制最终最优值的箱线图"""
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # 收集所有方法的最终最优值（按照指定顺序）
    final_values = {
        'CLEI': [],
        'EILGP': [],
        'EIFN': [],
        'EI': []
    }

    for result in all_results:
        final_values['CLEI'].append(
            result['y_best_clei'][-1] if result['y_best_clei'] else result['initial_best_y2']
        )
        final_values['EILGP'].append(
            result['y_best_eilgp'][-1] if result['y_best_eilgp'] else result['initial_best_y2']
        )
        final_values['EIFN'].append(
            result['y_best_eifn'][-1] if result['y_best_eifn'] else result['initial_best_y2']
        )
        final_values['EI'].append(
            result['y_best_ei'][-1] if result['y_best_ei'] else result['initial_best_y2']
        )

    # 创建箱线图
    fig, ax = plt.subplots(figsize=(10, 7))

    data_to_plot = [final_values[key] for key in final_values.keys()]
    labels = list(final_values.keys())

    bp = ax.boxplot(data_to_plot, labels=labels, patch_artist=True,
                    boxprops=dict(facecolor='lightblue', alpha=0.7),
                    medianprops=dict(color='darkred', linewidth=2.5),
                    whiskerprops=dict(linewidth=1.5),
                    capprops=dict(linewidth=1.5),
                    flierprops=dict(marker='o', markerfacecolor='red', markersize=6, alpha=0.5))

    # 添加颜色（与收敛图一致）
    colors = ['blue', 'red', 'magenta', 'green']
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.5)

    # 添加散点图显示所有数据点
    for i, (key, color) in enumerate(zip(final_values.keys(), colors), 1):
        y = final_values[key]
        x = np.random.normal(i, 0.04, size=len(y))
        ax.scatter(x, y, alpha=0.4, s=30, color=color, edgecolors='black', linewidth=0.5)

    ax.set_ylabel('Final Best Objective Value', fontsize=14, fontweight='bold')
    ax.set_title(f'Final Best Values Comparison ({DIM_LAYER1}D ActMat Function)', fontsize=16, fontweight='bold')
    ax.grid(True, alpha=0.3, linestyle='--', axis='y')

    # 添加统计信息
    for i, key in enumerate(final_values.keys(), 1):
        values = final_values[key]
        mean_val = np.mean(values)
        median_val = np.median(values)
        ax.text(i, ax.get_ylim()[1] * 0.95, f'Mean: {mean_val:.4f}\nMedian: {median_val:.4f}',
                ha='center', va='top', fontsize=9, bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    plt.tight_layout()
    plt.savefig(f'{output_dir}/final_boxplot_{timestamp}.png', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_dir}/final_boxplot_{timestamp}.pdf', bbox_inches='tight')
    print(f"箱线图已保存: {output_dir}/final_boxplot_{timestamp}.png")

    plt.show()

    # 打印详细统计
    print(f"\n{'=' * 80}")
    print("最终值统计 (所有实验)")
    print(f"{'=' * 80}")
    for key in final_values.keys():
        values = final_values[key]
        print(f"\n{key}:")
        print(f"  Mean:   {np.mean(values):.6f}")
        print(f"  Median: {np.median(values):.6f}")
        print(f"  Std:    {np.std(values):.6f}")
        print(f"  Min:    {np.min(values):.6f}")
        print(f"  Max:    {np.max(values):.6f}")
    print(f"{'=' * 80}\n")


# ------------------------
# 绘制运行时间箱线图函数
# ------------------------
def plot_runtime_boxplot(all_results, output_dir='results'):
    """绘制运行时间箱线图"""
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # 收集所有方法的运行时间（按照指定顺序）
    runtime_values = {
        'CLEI': [],
        'EILGP': [],
        'EIFN': [],
        'EI': []
    }

    for result in all_results:
        runtime_values['CLEI'].append(result['runtime_clei'])
        runtime_values['EILGP'].append(result['runtime_eilgp'])
        runtime_values['EIFN'].append(result['runtime_eifn'])
        runtime_values['EI'].append(result['runtime_ei'])

    # 创建箱线图
    fig, ax = plt.subplots(figsize=(10, 7))

    data_to_plot = [runtime_values[key] for key in runtime_values.keys()]
    labels = list(runtime_values.keys())

    bp = ax.boxplot(data_to_plot, labels=labels, patch_artist=True,
                    boxprops=dict(facecolor='lightblue', alpha=0.7),
                    medianprops=dict(color='darkred', linewidth=2.5),
                    whiskerprops=dict(linewidth=1.5),
                    capprops=dict(linewidth=1.5),
                    flierprops=dict(marker='o', markerfacecolor='red', markersize=6, alpha=0.5))

    # 添加颜色（与收敛图一致）
    colors = ['blue', 'red', 'magenta', 'green']
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.5)

    # 添加散点图显示所有数据点
    for i, (key, color) in enumerate(zip(runtime_values.keys(), colors), 1):
        y = runtime_values[key]
        x = np.random.normal(i, 0.04, size=len(y))
        ax.scatter(x, y, alpha=0.4, s=30, color=color, edgecolors='black', linewidth=0.5)

    ax.set_ylabel('Runtime (seconds)', fontsize=14, fontweight='bold')
    ax.set_title(f'Runtime Comparison ({DIM_LAYER1}D ActMat Function)', fontsize=16, fontweight='bold')
    ax.grid(True, alpha=0.3, linestyle='--', axis='y')

    # 添加统计信息
    for i, key in enumerate(runtime_values.keys(), 1):
        values = runtime_values[key]
        mean_val = np.mean(values)
        median_val = np.median(values)
        ax.text(i, ax.get_ylim()[1] * 0.95, f'Mean: {mean_val:.2f}s\nMedian: {median_val:.2f}s',
                ha='center', va='top', fontsize=9, bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    plt.tight_layout()
    plt.savefig(f'{output_dir}/runtime_boxplot_{timestamp}.png', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_dir}/runtime_boxplot_{timestamp}.pdf', bbox_inches='tight')
    print(f"运行时间箱线图已保存: {output_dir}/runtime_boxplot_{timestamp}.png")

    plt.show()

    # 打印详细统计
    print(f"\n{'=' * 80}")
    print("运行时间统计 (所有实验)")
    print(f"{'=' * 80}")
    for key in runtime_values.keys():
        values = runtime_values[key]
        print(f"\n{key}:")
        print(f"  Mean:   {np.mean(values):.2f} seconds")
        print(f"  Median: {np.median(values):.2f} seconds")
        print(f"  Std:    {np.std(values):.2f} seconds")
        print(f"  Min:    {np.min(values):.2f} seconds")
        print(f"  Max:    {np.max(values):.2f} seconds")
    print(f"{'=' * 80}\n")


def plot_performance_comparison(all_results, output_dir='results', normalize_method='minmax'):
    """绘制综合性能对比图（最优值 vs 运行时间）

    Args:
        all_results: 结果数据
        output_dir: 输出目录
        normalize_method: 标准化方法 ('minmax', 'zscore', 或 'robust')
    """
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # 收集数据
    methods = ['CLEI', 'EILGP', 'EIFN', 'EI']
    colors = ['blue', 'red', 'magenta', 'green']
    markers = ['o', 's', '^', 'd']

    final_values = {method: [] for method in methods}
    runtime_values = {method: [] for method in methods}

    for result in all_results:
        final_values['CLEI'].append(
            result['y_best_clei'][-1] if result['y_best_clei'] else result['initial_best_y2']
        )
        final_values['EILGP'].append(
            result['y_best_eilgp'][-1] if result['y_best_eilgp'] else result['initial_best_y2']
        )
        final_values['EIFN'].append(
            result['y_best_eifn'][-1] if result['y_best_eifn'] else result['initial_best_y2']
        )
        final_values['EI'].append(
            result['y_best_ei'][-1] if result['y_best_ei'] else result['initial_best_y2']
        )

        runtime_values['CLEI'].append(result['runtime_clei'])
        runtime_values['EILGP'].append(result['runtime_eilgp'])
        runtime_values['EIFN'].append(result['runtime_eifn'])
        runtime_values['EI'].append(result['runtime_ei'])

    # 收集所有数据用于标准化
    all_runtimes = []
    all_performances = []
    for method in methods:
        all_runtimes.extend(runtime_values[method])
        all_performances.extend(final_values[method])

    all_runtimes = np.array(all_runtimes)
    all_performances = np.array(all_performances)

    # 定义标准化函数
    def normalize_data(data, method='minmax'):
        data = np.array(data)
        if method == 'minmax':
            # Min-Max标准化到[0, 1]
            return (data - data.min()) / (data.max() - data.min() + 1e-10)
        elif method == 'zscore':
            # Z-score标准化
            return (data - data.mean()) / (data.std() + 1e-10)
        elif method == 'robust':
            # 基于中位数和四分位距的鲁棒标准化
            median = np.median(data)
            q75, q25 = np.percentile(data, [75, 25])
            iqr = q75 - q25
            return (data - median) / (iqr + 1e-10)
        else:
            return data

    # 对所有数据进行标准化
    all_runtimes_norm = normalize_data(all_runtimes, normalize_method)
    all_performances_norm = normalize_data(all_performances, normalize_method)

    # 将标准化后的数据重新分配回各方法
    runtime_values_norm = {method: [] for method in methods}
    final_values_norm = {method: [] for method in methods}

    idx = 0
    for method in methods:
        n_samples = len(runtime_values[method])
        runtime_values_norm[method] = all_runtimes_norm[idx:idx + n_samples].tolist()
        final_values_norm[method] = all_performances_norm[idx:idx + n_samples].tolist()
        idx += n_samples

    # 创建散点图
    fig, ax = plt.subplots(figsize=(10, 7))

    for method, color, marker in zip(methods, colors, markers):
        x = runtime_values_norm[method]
        y = final_values_norm[method]

        # 绘制所有点
        ax.scatter(x, y, alpha=0.3, s=100, color=color, marker=marker)

        # 绘制均值点（大）
        mean_x = np.mean(x)
        mean_y = np.mean(y)
        ax.scatter(mean_x, mean_y, s=300, color=color, marker=marker,
                   edgecolors='black', linewidth=2, label=method, zorder=5)

        # 添加误差棒
        std_x = np.std(x)
        std_y = np.std(y)
        ax.errorbar(mean_x, mean_y, xerr=std_x, yerr=std_y,
                    color=color, capsize=5, capthick=2, linewidth=2, alpha=0.6, zorder=4)

    # 根据标准化方法调整标签
    if normalize_method == 'minmax':
        xlabel = 'Normalized Runtime (Min-Max)'
        ylabel = 'Normalized Performance (Min-Max)'
    elif normalize_method == 'zscore':
        xlabel = 'Normalized Runtime (Z-score)'
        ylabel = 'Normalized Performance (Z-score)'
    elif normalize_method == 'robust':
        xlabel = 'Normalized Runtime (Robust)'
        ylabel = 'Normalized Performance (Robust)'
    else:
        xlabel = 'Runtime (seconds)'
        ylabel = 'Final Best Objective Value'

    ax.set_xlabel(xlabel, fontsize=14, fontweight='bold')
    ax.set_ylabel(ylabel, fontsize=14, fontweight='bold')
    ax.set_title(f'Performance vs Runtime Trade-off ({DIM_LAYER1}D ActMat Function)', fontsize=16, fontweight='bold')
    ax.legend(fontsize=11, loc='best', framealpha=0.9)
    ax.grid(True, alpha=0.3, linestyle='--')

    plt.tight_layout()
    plt.savefig(f'{output_dir}/performance_vs_runtime_normalized_{timestamp}.png', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_dir}/performance_vs_runtime_normalized_{timestamp}.pdf', bbox_inches='tight')
    print(f"标准化性能对比图已保存: {output_dir}/performance_vs_runtime_normalized_{timestamp}.png")

    plt.show()


# ------------------------
# 主程序
# ------------------------
if __name__ == "__main__":
    NUM_EXPERIMENTS = 100

    print(f"\n{'=' * 80}")
    print(f"Running {NUM_EXPERIMENTS} Independent Experiments ({DIM_LAYER1}D Version with EIFN)")
    print(f"Sequential Budget: {SEQUENTIAL_BUDGET}")
    print(f"{'=' * 80}\n")

    all_results = []

    for exp_id in range(NUM_EXPERIMENTS):
        print(f"\n{'=' * 80}")
        print(f"EXPERIMENT {exp_id + 1}/{NUM_EXPERIMENTS} (Seed: {BASE_SEED + exp_id})")
        print(f"{'=' * 80}")
        result = run_single_experiment(
            seed=BASE_SEED + exp_id,
            sequential_budget=SEQUENTIAL_BUDGET,
            dim=DIM_LAYER1,
            verbose=False
        )
        all_results.append(result)

        print(f"\nExperiment {exp_id + 1} Summary:")
        print(f"  Initial Best:  {result['initial_best_y2']:.6f}")
        print(
            f"  CLEI:   {result['y_best_clei'][-1] if result['y_best_clei'] else result['initial_best_y2']:.6f} ({result['runtime_clei']:.1f}s)")
        print(
            f"  EILGP:  {result['y_best_eilgp'][-1] if result['y_best_eilgp'] else result['initial_best_y2']:.6f} ({result['runtime_eilgp']:.1f}s)")
        print(
            f"  EI:     {result['y_best_ei'][-1] if result['y_best_ei'] else result['initial_best_y2']:.6f} ({result['runtime_ei']:.1f}s)")
        print(
            f"  EIFN:   {result['y_best_eifn'][-1] if result['y_best_eifn'] else result['initial_best_y2']:.6f} ({result['runtime_eifn']:.1f}s)")

    output_dir = f'results_{DIM_LAYER1}d'

    # 保存结果
    print(f"\n{'=' * 80}")
    print("保存实验结果...")
    print(f"{'=' * 80}")
    summary_df = save_results(all_results, output_dir=output_dir)

    # 打印汇总统计
    print(f"\n{'=' * 80}")
    print("汇总统计 (所有实验)")
    print(f"{'=' * 80}")
    # 从 all_results 直接计算汇总统计
    def _finals(key, init_key):
        return [r[key][-1] if r[key] else r[init_key] for r in all_results]

    clei_finals  = np.array(_finals('y_best_clei',  'initial_best_y2'))
    eilgp_finals = np.array(_finals('y_best_eilgp', 'initial_best_y2'))
    ei_finals    = np.array(_finals('y_best_ei',    'initial_best_y2'))
    eifn_finals  = np.array(_finals('y_best_eifn',  'initial_best_y2'))

    print(f"\nFinal Best Values (Mean ± Std):")
    print(f"  CLEI:  {clei_finals.mean():.6f} ± {clei_finals.std():.6f}")
    print(f"  EILGP: {eilgp_finals.mean():.6f} ± {eilgp_finals.std():.6f}")
    print(f"  EI:    {ei_finals.mean():.6f} ± {ei_finals.std():.6f}")
    print(f"  EIFN:  {eifn_finals.mean():.6f} ± {eifn_finals.std():.6f}")

    print(f"\nAverage Runtime (seconds):")
    print(f"  CLEI:  {summary_df['CLEI_time_s'].mean():.2f} ± {summary_df['CLEI_time_s'].std():.2f}")
    print(f"  EILGP: {summary_df['EILGP_time_s'].mean():.2f} ± {summary_df['EILGP_time_s'].std():.2f}")
    print(f"  EI:    {summary_df['EI_time_s'].mean():.2f} ± {summary_df['EI_time_s'].std():.2f}")
    print(f"  EIFN:  {summary_df['EIFN_time_s'].mean():.2f} ± {summary_df['EIFN_time_s'].std():.2f}")

    print(f"\nAverage Iterations:")
    print(f"  CLEI:  {np.mean([r['n_iterations_clei']  for r in all_results]):.1f}")
    print(f"  EILGP: {np.mean([r['n_iterations_eilgp'] for r in all_results]):.1f}")
    print(f"  EI:    {np.mean([r['n_iterations_ei']    for r in all_results]):.1f}")
    print(f"  EIFN:  {np.mean([r['n_iterations_eifn']  for r in all_results]):.1f}")

    # 绘制收敛图
    print(f"\n{'=' * 80}")
    print("绘制收敛曲线...")
    print(f"{'=' * 80}")
    # plot_convergence_curves(all_results, output_dir=output_dir, show_individual=False)

    # 绘制最优值箱线图
    print(f"\n{'=' * 80}")
    print("绘制最优值箱线图...")
    print(f"{'=' * 80}")
    # plot_final_boxplot(all_results, output_dir=output_dir)

    # 绘制运行时间箱线图
    print(f"\n{'=' * 80}")
    print("绘制运行时间箱线图...")
    print(f"{'=' * 80}")
    # plot_runtime_boxplot(all_results, output_dir=output_dir)

    # 绘制综合性能对比图
    print(f"\n{'=' * 80}")
    print("绘制综合性能对比图...")
    print(f"{'=' * 80}")
    # plot_performance_comparison(all_results, output_dir=output_dir)

    print(f"\n{'=' * 80}")
    print("所有任务完成!")
    print(f"{'=' * 80}\n")