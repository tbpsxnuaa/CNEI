import pickle
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon

plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 14
plt.rcParams['axes.titlesize'] = 15
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['xtick.labelsize'] = 13
plt.rcParams['ytick.labelsize'] = 13
plt.rcParams['legend.fontsize'] = 13

# ── 配置 ──────────────────────────────────────────────
PKL_FILE     = r"D:\python code\linked_bo\bo_results\gpnet3_100rep_results.pkl"  # 按你本地实际路径修改
OUT_IMPROVE  = r"D:\python code\linked_bo\bo_results\paired_improvement.pdf"
OUT_COST     = r"D:\python code\linked_bo\bo_results\cost_to_threshold.pdf"
# ──────────────────────────────────────────────────────

algos  = ['EI', 'EIFN', 'EILGP', 'CLEI']
colors = {'EI': '#1f77b4', 'CLEI': '#ff7f0e', 'EIFN': '#2ca02c', 'EILGP': '#d62728'}
display_name = {'EI': 'EI', 'EIFN': 'EIFN', 'EILGP': 'EILGP', 'CLEI': 'CNEI'}

with open(PKL_FILE, 'rb') as f:
    data = pickle.load(f)   # list, 长度 100, 每项是 dict[algo] -> {'bsf':..., 'final_best':...}

n_reps = len(data)

final_best = {a: np.array([rep[a]['final_best'] for rep in data]) for a in algos}
bsf        = {a: np.vstack([rep[a]['bsf'] for rep in data]) for a in algos}  # shape (100, 501)
# 注意：bsf 的下标本身即累计 cost（0 ~ 500）

# ============================================================
# ⑤ 配对提升分析：CNEI 相对各基线的提升幅度 (final_best 越小越好)
# ============================================================
baselines = ['EI', 'EIFN', 'EILGP']
# improve > 0 表示 CNEI 更优（更小）
improve = {b: final_best[b] - final_best['CLEI'] for b in baselines}

fig, ax = plt.subplots(figsize=(7, 5))
box_data = [improve[b] for b in baselines]
bp = ax.boxplot(
    box_data,
    labels=[f"CNEI vs {b}" for b in baselines],
    patch_artist=True,
    medianprops=dict(color='black', linewidth=1.5),
    whiskerprops=dict(linewidth=1.2),
    capprops=dict(linewidth=1.2),
    flierprops=dict(marker='o', markersize=4, linestyle='none', alpha=0.5),
)
for patch, b in zip(bp['boxes'], baselines):
    patch.set_facecolor(colors[b])
    patch.set_alpha(0.6)
ax.axhline(0, color='gray', linestyle='--', linewidth=1)
ax.set_ylabel('Improvement over baseline\n(baseline final_best − CNEI final_best)')
ax.grid(True, axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(OUT_IMPROVE, bbox_inches='tight')
print(f"Saved to {OUT_IMPROVE}")
plt.show()

print("=== CNEI 相对各基线的配对提升 (n=100, paired Wilcoxon) ===")
for b in baselines:
    diff = improve[b]
    stat, p = wilcoxon(diff)
    win_rate = np.mean(diff > 0)
    print(f"CNEI vs {b}: mean_improve={diff.mean():.4f}, median_improve={np.median(diff):.4f}, "
          f"win_rate={win_rate:.1%}, wilcoxon p={p:.4g}")

# ============================================================
# ⑥ 达到目标水平所需的累计成本 (cost-to-reach-threshold)
# ============================================================
# 阈值：以最弱基线 EI 在 100 次重复上的平均最终值作为目标水平
# （即"其他方法要花多少 cost 才能达到 EI 平均水平"）
threshold = final_best['EI'].mean()
print(f"\n阈值(threshold) = EI 的平均 final_best = {threshold:.4f}")

def cost_to_reach(bsf_row, threshold):
    if bsf_row[-1] > threshold:      # 预算用完仍未达到阈值
        return np.nan
    return int(np.argmax(bsf_row <= threshold))  # 下标本身即 cost

cost_reach  = {}
not_reached = {}
for a in algos:
    costs = np.array([cost_to_reach(bsf[a][i], threshold) for i in range(n_reps)], dtype=float)
    cost_reach[a] = costs
    not_reached[a] = int(np.isnan(costs).sum())

print("\n=== 达到阈值所需的累计成本 (n=100) ===")
for a in algos:
    valid = cost_reach[a][~np.isnan(cost_reach[a])]
    print(f"{display_name[a]}: mean_cost={valid.mean():.1f}, median_cost={np.median(valid):.1f}, "
          f"未在预算内达到阈值={not_reached[a]}/{n_reps}")

fig, ax = plt.subplots(figsize=(7, 5))
box_data   = [cost_reach[a][~np.isnan(cost_reach[a])] for a in algos]
labels     = [display_name[a] for a in algos]
bp = ax.boxplot(
    box_data,
    labels=labels,
    patch_artist=True,
    medianprops=dict(color='black', linewidth=1.5),
    whiskerprops=dict(linewidth=1.2),
    capprops=dict(linewidth=1.2),
    flierprops=dict(marker='o', markersize=4, linestyle='none', alpha=0.5),
)
for patch, a in zip(bp['boxes'], algos):
    patch.set_facecolor(colors[a])
    patch.set_alpha(0.6)
ax.set_xlabel('Algorithm')
ax.set_ylabel(f'Cumulative Cost to Reach Threshold\n(target = {threshold:.2f})')
ax.grid(True, axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(OUT_COST, bbox_inches='tight')
print(f"Saved to {OUT_COST}")
plt.show()