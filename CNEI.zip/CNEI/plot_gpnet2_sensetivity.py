import os
import pickle
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.interpolate import RegularGridInterpolator
from scipy.spatial.distance import cdist

plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman', 'Liberation Serif',
                              'DejaVu Serif']
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['axes.labelsize'] = 15
plt.rcParams['axes.titlesize'] = 15
plt.rcParams['xtick.labelsize'] = 12
plt.rcParams['ytick.labelsize'] = 12

SAVE_DIR = os.path.dirname(os.path.abspath(__file__))

# ── (a) 重建 GP 样本并做方差分解 ─────────────────────────────────────────

def _rbf_1d(x, ls, os_=1.0):
    x = np.atleast_2d(x).reshape(-1, 1) / ls
    return os_ * np.exp(-0.5 * cdist(x, x, 'sqeuclidean'))


def sample_1d(grid, ls, os_, seed):
    K = _rbf_1d(grid, ls, os_) + 1e-8 * np.eye(len(grid))
    rng = np.random.default_rng(seed)
    f = np.linalg.cholesky(K) @ rng.standard_normal(len(grid))
    return RegularGridInterpolator([grid], f, method='linear',
                                   bounds_error=False, fill_value=None)


def sample_2d(g1, g2, ls, os_, seed):
    L1 = np.linalg.cholesky(_rbf_1d(g1, ls[0], os_) + 1e-10 * np.eye(len(g1)))
    L2 = np.linalg.cholesky(_rbf_1d(g2, ls[1], 1.0) + 1e-10 * np.eye(len(g2)))
    rng = np.random.default_rng(seed)
    Z = rng.standard_normal(len(g1) * len(g2)).reshape(len(g1), len(g2))
    return RegularGridInterpolator([g1, g2], L1 @ Z @ L2.T, method='linear',
                                   bounds_error=False, fill_value=None)


X1_GRID = np.linspace(-2, 2, 201)
F1 = sample_1d(X1_GRID, 0.5, 2, seed=88)
p = F1(np.linspace(-2, 2, 400).reshape(-1, 1)).flatten()
Y1_LO, Y1_HI = p.min() - 0.5, p.max() + 0.5
Y1_GRID = np.linspace(Y1_LO, Y1_HI, 101)
X2_GRID = np.linspace(-2, 2, 101)

SETTINGS = {'[0.1, 0.9]': [0.1, 0.9], '[0.9, 0.1]': [0.9, 0.1]}
y1f = np.linspace(Y1_LO, Y1_HI, 300)
x2f = np.linspace(-2, 2, 300)
YY, XX = np.meshgrid(y1f, x2f, indexing='ij')
PTS = np.column_stack([YY.ravel(), XX.ravel()])

labels, s_y1, s_x2, s_int = [], [], [], []
for k, ls in SETTINGS.items():
    F = sample_2d(Y1_GRID, X2_GRID, ls, 6.0, seed=185)(PTS).reshape(300, 300)
    total = F.var()
    v1 = F.mean(axis=1).var() / total
    v2 = F.mean(axis=0).var() / total
    labels.append(k); s_y1.append(v1); s_x2.append(v2)
    s_int.append(max(0.0, 1 - v1 - v2))

# ── (b) layer1 选择比例数据 ──────────────────────────────────────────────
PKLS = {
    r'$\theta_2 = [0.1, 0.9]$':
        os.path.join(SAVE_DIR, '0.1_0.9_cnei.pkl'),
    r'$\theta_2 = [0.9, 0.1]$':
        os.path.join(SAVE_DIR, '0.9_0.1_cnei.pkl'),
}
BUDGET, BIN_W = 500.0, 25.0
bins = np.arange(0, BUDGET + BIN_W, BIN_W)
mids = 0.5 * (bins[:-1] + bins[1:])
LINE_COLORS = ['#4C72B0', '#DD8452']

# ── 画图 ────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.6))

# (a) 方差分解
ax = axes[0]
x = np.arange(len(labels)); w = 0.25
b1 = ax.bar(x - w, s_y1, w, label=r'$S_{y_1}$ (main effect of $y_1$)')
b2 = ax.bar(x,     s_x2, w, label=r'$S_{x_2}$ (main effect of $x_2$)')
b3 = ax.bar(x + w, s_int, w, label='interaction')
for bars in (b1, b2, b3):
    ax.bar_label(bars, fmt='%.3f', fontsize=10)
ax.set_xticks(x, [fr'$\theta_2 = {k}$' for k in labels])
ax.set_ylabel(r'share of Var($f_2$)')
ax.set_title(r'(a) Variance Decomposition of $f_2$')
ax.legend(fontsize=10)
ax.set_ylim(0, 1.05)

# (b) layer1 选择比例
ax = axes[1]
for ci, (label, path) in enumerate(PKLS.items()):
    with open(path, 'rb') as f:
        runs = [r for r in pickle.load(f) if r is not None]
    cost, is_l1 = [], []
    for r in runs:
        for rec in r['iteration_log']:
            cost.append(rec['cost_cumulative'])
            is_l1.append(rec['strategy'] == 'layer1')
    cost = np.array(cost); is_l1 = np.array(is_l1)
    l1c, _ = np.histogram(cost[is_l1], bins=bins)
    tot, _ = np.histogram(cost, bins=bins)
    share = np.where(tot > 0, l1c / np.maximum(tot, 1), np.nan)
    ax.plot(mids, share, 'o-', ms=4, color=LINE_COLORS[ci], label=label)
ax.set_xlabel('Cumulative cost')
ax.set_ylabel('layer1 share of decisions')
ax.set_title('(b) Layer1 Selection Rate over the Budget')
ax.set_ylim(0, 0.6)
ax.grid(alpha=0.3)
ax.legend(fontsize=10)

fig.tight_layout()
for ext in ('pdf', 'png'):
    out = os.path.join(SAVE_DIR, f'sobol_and_layer1rate.{ext}')
    fig.savefig(out, dpi=300, bbox_inches='tight')
    print('saved:', out)
plt.close(fig)