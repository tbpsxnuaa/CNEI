"""
gpnet_50rep.py
==============
基于 GP-sample 函数网络测试问题，对 CLEI / EILGP / EIFN / EI 四种方法
各运行 50 次独立重复实验，输出：
  1. 每次重复结果（pkl 缓存）
  2. 50 次平均的 best-so-far 曲线（按累计代价）
  3. 最终最优值的均值 ± 标准差汇总表

函数网络结构
-----------
  第一层：f1(x1) → y1
    · x1 ∈ [-2, 2]，GP sample，RBF 核，length_scale=0.5，output_scale=2.0
  第二层：f2(y1, x2) → y2
    · x1 ∈ [-2, 2]，(y1, x2) ∈ R²，GP sample，RBF 核，
      length_scale=[0.1, 0.9]（y1 方向更敏感），output_scale=6.0
  目标：最小化 y2

参数设计说明
-----------
  · y1 方向 length_scale=0.4 << x2 方向 length_scale=6.0
    → y1 对 f2 的边际影响显著大于 x2，使得能正确建模 y1→y2 耦合的方法
      （CLEI/EILGP/EIFN）相对于忽略网络结构的黑箱 EI 具有建模优势。
  · f1 的 output_scale=3.0，使 y1 的实际输出范围宽（约 [-2,2]），
    进一步放大忽略 y1 信息所带来的预测误差。

CLEI 策略说明（本版本已移除 'both' 联合采集选项）
-----------
  CLEI 每次迭代只在两种"按节点划分"的采集函数之间比较、二选一：
    · layer1        —— 仅评估 f1(x1)，代价 COST_LAYER1，不产生 y2 观测
    · layer2_reuse  —— 复用已有的某个 y1 观测，仅评估 f2(y1,x2)，
                        代价 COST_LAYER2，产生 y2 观测
  不再存在"同时评估 f1 和 f2（联合采一个新点）"的第三种选项，
  也移除了原来"EI 收敛→强制 both"的判据。

异常处理策略（本版本新增）
-----------
  四种方法各自内部仍保留"连续 max_retries 次拟合/优化异常"的重试机制
  （给偶发数值抖动一个自愈的机会）。但如果某个方法把重试次数用尽仍然
  失败，不再像之前那样默默保留该方法此前的部分结果、跳过继续——而是
  直接抛出异常，导致 _run_one() 整体失败。run_all_reps() 捕获到这种
  失败后，会**丢弃这一整次重复（四种方法的结果都不要）**，换一个新的
  随机种子重新完整跑一次，直到成功（四种方法都跑满预算、没有异常）才
  把结果计入第 i 次重复。这样保存到 pkl / 参与汇总统计的，
  永远都是"四种方法全部正常跑完"的干净结果，不会出现有的方法是完整
  跑满预算的结果、有的方法是提前夭折的部分结果这种口径不一致的情况。
"""

import os
import pickle
import warnings
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm
from scipy.interpolate import RegularGridInterpolator
from scipy.spatial.distance import cdist

from dgpsi import kernel, container, lgp, gp
from pyDOE2 import lhs

# =============================================================================
# GP-sample 仿真函数（模块加载时预计算，保证每次调用确定性）
#
# 参数选择依据：
#   f1: length_scale=0.5  → x1 空间变化剧烈，y1 输出范围宽（≈[-2,2]）
#       output_scale=3.0  → 加大 y1 的绝对幅度
#   f2: length_scale=[0.4, 6.0]
#       · y1 方向 0.4（短程相关）→ y1 微小变化即引起 f2 显著变化
#       · x2 方向 6.0（长程相关）→ x2 对 f2 影响平缓
#       output_scale=6.0  → 保持 f2 输出量级
#   综合效果：y1 的边际重要性约为 x2 的 1.6 倍，
#   使正确建模耦合结构的方法具有明显优势。
# =============================================================================

def _rbf_kernel(X1, X2, length_scale, output_scale=1.0):
    X1 = np.atleast_2d(X1); X2 = np.atleast_2d(X2)
    if np.isscalar(length_scale):
        X1s = X1 / length_scale; X2s = X2 / length_scale
    else:
        X1s = X1 / np.array(length_scale)
        X2s = X2 / np.array(length_scale)
    dists = cdist(X1s, X2s, metric='sqeuclidean')
    return output_scale * np.exp(-0.5 * dists)


def _sample_gp_path(grid_points_list, length_scale, output_scale, seed):
    grids   = np.meshgrid(*grid_points_list, indexing='ij')
    X_grid  = np.column_stack([g.ravel() for g in grids])
    K       = _rbf_kernel(X_grid, X_grid, length_scale, output_scale)
    K      += 1e-8 * np.eye(len(X_grid))
    rng     = np.random.default_rng(seed)
    L       = np.linalg.cholesky(K)
    z       = rng.standard_normal(len(X_grid))
    f_vals  = L @ z
    shape   = tuple(len(g) for g in grid_points_list)
    return RegularGridInterpolator(
        grid_points_list, f_vals.reshape(shape),
        method='linear', bounds_error=False, fill_value=None)

# =============================================================================
# 全局参数
# =============================================================================
DIM_LAYER1        = 1
COST_LAYER1       = 1.0
COST_LAYER2       = 9.0
COST_BOTH         = COST_LAYER1 + COST_LAYER2   # 仍用于 EI/EIFN/EILGP 每步的联合采样代价
SEQUENTIAL_BUDGET = 500.0

N_REPS      = 100          # 重复次数
BASE_SEED   = 1           # 第 i 次实验使用 seed = BASE_SEED + i

MAX_ATTEMPTS_PER_REP = 50  # 单次重复最多重新开始多少次（换新种子重试的上限，防止极端情况下死循环）

SAVE_DIR  = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = os.path.join(SAVE_DIR, 's2_0.1_0.9_gpnet2_100rep_results.pkl')

N_INIT = 2 * (DIM_LAYER1 + 1 + 1)   # = 6

# 代价轴（用于绘制/对齐 best-so-far 曲线的参考刻度）
# 从 0 到 SEQUENTIAL_BUDGET，步长为 COST_LAYER1（最小步长）
COST_AXIS = np.arange(0, SEQUENTIAL_BUDGET + COST_LAYER1, COST_LAYER1)

METHODS = ['EI', 'EIFN', 'EILGP', 'CLEI']
BOUNDS = [(-2.0, 2.0)] * DIM_LAYER1 + [(-2.0, 2.0)]
_X1_GRID   = np.linspace(-2.0, 2.0, 201)
_F1_INTERP = _sample_gp_path([_X1_GRID], 0.5, 2, seed=88)

# y1 实际输出范围估计（用于确定 f2 的 y1 轴网格范围）
_Y1_PROBE  = _F1_INTERP(np.linspace(-2, 2, 400).reshape(-1, 1)).flatten()
_Y1_LO     = _Y1_PROBE.min() - 0.5
_Y1_HI     = _Y1_PROBE.max() + 0.5

_Y1_GRID   = np.linspace(_Y1_LO, _Y1_HI, 101)
_X2_GRID   = np.linspace(-2.0, 2.0, 101)
_F2_INTERP = _sample_gp_path(    [_Y1_GRID, _X2_GRID], [0.1, 0.9], 6.0, seed=185)


def f1(x1):
    """x1(n,1) → y1(n,1)"""
    return _F1_INTERP(np.atleast_2d(x1).reshape(-1, 1)).reshape(-1, 1)

def f2(y1, x2):
    """(y1,x2)(n,2) → y2(n,1)"""
    pts = np.hstack([np.atleast_2d(y1).reshape(-1, 1),
                     np.atleast_2d(x2).reshape(-1, 1)])
    return _F2_INTERP(pts).reshape(-1, 1)


# =============================================================================
# EI 计算
# =============================================================================

def EI_from_ml_vl(ml, vl, best_f, xi=0.0):
    sigma       = np.sqrt(np.maximum(vl, 1e-12))
    improvement = best_f - ml - xi
    u           = improvement / sigma
    return improvement * norm.cdf(u) + sigma * norm.pdf(u)


# =============================================================================
# lgp 辅助
# =============================================================================

def fit_gp1(X1, Y1):
    m = gp(X1, Y1, kernel(length=np.ones(DIM_LAYER1), nugget=1e-6,
                           name='matern2.5', scale_est=True))
    m.train(); return m


def fit_gp2_connected(X2, Y2):
    """X2[:,0]=y1（第一层传播），X2[:,1]=x2（外部输入，connect）"""
    m = gp(X2, Y2, kernel(length=np.ones(2), nugget=1e-6, name='matern2.5',
                           scale_est=True,
                           input_dim=np.array([0]), connect=np.array([1])))
    m.train(); return m


def build_lgp_model(m1, m2):
    c1 = container(m1.export(), local_input_idx=np.arange(DIM_LAYER1))
    c2 = container(m2.export(), local_input_idx=np.array([0]))
    return lgp([[c1], [c2]], N=10)


def build_lgp_input(x):
    x        = np.asarray(x).reshape(-1)
    X_global = x[:DIM_LAYER1].reshape(1, -1)
    x2_ext   = x[DIM_LAYER1:DIM_LAYER1 + 1].reshape(1, -1)
    return [X_global, [x2_ext]]


def standard_EI(x, model_lgp, best_f):
    ml, vl = model_lgp.predict(build_lgp_input(x))
    return EI_from_ml_vl(ml[0][0, 0], vl[0][0, 0], best_f)


# =============================================================================
# EIFN
# =============================================================================

class EIFN_Optimizer:
    def __init__(self, bounds, n_samples=50, n_restarts=15):
        self.bounds    = bounds
        self.n_samples = n_samples
        self.n_restart = n_restarts
        self.X1_data = self.Y1_data = self.X2_data = self.Y2_data = None
        self.gp1 = self.gp2 = None
        self.best_y2 = np.inf

    def add_observation(self, x1, x2):
        x1 = np.atleast_2d(x1).reshape(1, -1)
        x2 = float(x2)
        y1 = f1(x1); y2 = f2(y1, np.array([[x2]]))
        row2 = np.hstack((y1, np.array([[x2]])))
        if self.X1_data is None:
            self.X1_data = x1;   self.Y1_data = y1
            self.X2_data = row2; self.Y2_data = y2
        else:
            self.X1_data = np.vstack((self.X1_data, x1))
            self.Y1_data = np.vstack((self.Y1_data, y1))
            self.X2_data = np.vstack((self.X2_data, row2))
            self.Y2_data = np.vstack((self.Y2_data, y2))
        self.best_y2 = min(self.best_y2, float(y2))
        return y2

    def update_models(self):
        self.gp1 = gp(self.X1_data, self.Y1_data,
                      kernel(length=np.ones(DIM_LAYER1), nugget=1e-6,
                             name='matern2.5', scale_est=True))
        self.gp1.train()
        self.gp2 = gp(self.X2_data, self.Y2_data,
                      kernel(length=np.ones(2), nugget=1e-6,
                             name='matern2.5', scale_est=True))
        self.gp2.train()

    def _sample_posterior(self, x, Z):
        x1 = x[:DIM_LAYER1].reshape(1, -1); x2 = x[DIM_LAYER1]
        mu1, v1 = self.gp1.predict(x1)
        y1s = mu1.flat[0] + np.sqrt(max(v1.flat[0], 1e-12)) * Z[0]
        mu2, v2 = self.gp2.predict(np.array([[y1s, x2]]))
        return mu2.flat[0] + np.sqrt(max(v2.flat[0], 1e-12)) * Z[1]

    def compute_ei_saa(self, x, Z_samples):
        return np.mean([max(self.best_y2 - self._sample_posterior(x, Z), 0)
                        for Z in Z_samples])

    def optimize_acquisition(self):
        Z_samples = np.random.randn(self.n_samples, 2)
        best_x, best_ei = None, -np.inf
        for _ in range(self.n_restart):
            x0  = np.array([np.random.uniform(b[0], b[1]) for b in self.bounds])
            res = minimize(lambda x: -self.compute_ei_saa(x, Z_samples),
                           x0, bounds=self.bounds, method='L-BFGS-B')
            if res.success and -res.fun > best_ei:
                best_ei = -res.fun; best_x = res.x
        if best_x is None:
            best_x = np.array([np.random.uniform(b[0], b[1])
                                for b in self.bounds])
        return best_x, best_ei


# =============================================================================
# CLEI 辅助函数
# =============================================================================

def _optimize_layer2(Y1_data, m2, best_f, x2_bounds, n_restart=15):
    """在已有的每个 y1 观测上，优化 x2 使 f2(y1,x2) 的 EI 最大。"""
    best_y1 = best_x2 = None; best_ei = -1e20
    for y1c in Y1_data.flatten():
        best_ei_local = -1e20; best_x2_local = None
        for _ in range(n_restart):
            x2_init = np.random.uniform(x2_bounds[0], x2_bounds[1])
            def obj(xp):
                ml, vl = m2.predict(np.array([[y1c, xp[0]]]))
                return -EI_from_ml_vl(ml.flat[0], vl.flat[0], best_f)
            res = minimize(obj, [x2_init], bounds=[x2_bounds], method='L-BFGS-B')
            if res.success:
                xp = res.x[0]
                ml, vl = m2.predict(np.array([[y1c, xp]]))
                ei = EI_from_ml_vl(ml.flat[0], vl.flat[0], best_f)
                if ei > best_ei_local:
                    best_ei_local = ei; best_x2_local = xp
        if best_ei_local > best_ei:
            best_ei = best_ei_local; best_y1 = y1c; best_x2 = best_x2_local
    return best_y1, best_x2, best_ei


def _optimize_layer1_marginal(model_lgp, best_f, bounds, n_restart=15):
    """
    联合优化 (x1,x2) 得到的 EI，仅用作 layer1 边际信息价值的估计
    （不作为可选的采样动作，CLEI 不会真的联合采一个新点）。
    """
    dim = DIM_LAYER1
    best_x, best_ei = None, -1e20
    for _ in range(n_restart):
        x0  = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
        res = minimize(lambda x: -standard_EI(x, model_lgp, best_f),
                       x0, bounds=bounds, method='L-BFGS-B')
        if res.success and -res.fun > best_ei:
            best_ei = -res.fun; best_x = res.x
    if best_x is None:
        best_x = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
        best_ei = standard_EI(best_x, model_lgp, best_f)
    return best_x[:dim], best_ei


def _clei_strategy(model_lgp, m2, Y1_data, best_f, bounds, n_restart=15):
    """
    CLEI 策略选择（已移除 'both' 联合采集选项、已移除 EI 收敛强制判据）。

    每次迭代只在两种"按节点划分"的采集函数之间二选一：
      · layer1       —— 仅评估 f1(x1)，代价 COST_LAYER1
      · layer2_reuse —— 复用已有 y1，仅评估 f2(y1,x2)，代价 COST_LAYER2
    按各自的单位代价 EI（EI/cost）贪心选择。

    ei_l1 通过联合优化 (x1,x2) 的 EI 近似估计 layer1 的边际信息价值
    （该联合优化点本身不会被采样，只用于估值）。
    """
    dim = DIM_LAYER1
    y1r, x2r, ei_l2r = _optimize_layer2(
        Y1_data, m2, best_f, bounds[dim], n_restart)
    x1_est, ei_l1 = _optimize_layer1_marginal(
        model_lgp, best_f, bounds, n_restart)

    ei_pc_l1  = (ei_l1 - ei_l2r) / COST_LAYER1
    ei_pc_l2r = ei_l2r           / COST_LAYER2

    candidates = {
        'layer1':       (ei_pc_l1,  x1_est),
        'layer2_reuse': (ei_pc_l2r, (y1r, x2r)),
    }
    strategy, (ei_per_cost, opt_x) = max(candidates.items(),
                                          key=lambda kv: kv[1][0])

    return strategy, opt_x, ei_per_cost, (ei_l1, ei_l2r)


# =============================================================================
# best-so-far 曲线工具
# =============================================================================

def _bsf_curve(cost_log, y2_log, cost_axis=COST_AXIS):
    """
    给定一次实验中每步的 (累计代价, 最优y2) 记录，
    插值到统一 cost_axis 上，返回 best-so-far 曲线。
    """
    curve = np.full(len(cost_axis), np.nan)
    if len(cost_log) == 0:
        return curve
    cost_log = np.asarray(cost_log)
    y2_log   = np.asarray(y2_log)
    # 初始值（代价=0 处）
    bsf = y2_log[0]
    ci  = 0
    for t, (c, y) in enumerate(zip(cost_log, y2_log)):
        bsf = min(bsf, y)
        # 填充 cost_axis 中 <= c 的所有位置
        while ci < len(cost_axis) and cost_axis[ci] <= c + 1e-9:
            curve[ci] = bsf
            ci += 1
    # 填充剩余部分（保持最后的 bsf）
    curve[ci:] = bsf
    return curve


# =============================================================================
# 单次实验
# =============================================================================

def _run_one(seed):
    """
    运行一次完整实验，返回：
      {method: {'bsf': best-so-far 曲线, 'final_best': 最终最优值}}

    与旧版本的区别：任何一种方法如果连续 max_retries 次拟合/优化异常，
    不再悄悄保留该方法此前的部分结果并继续——而是直接抛出异常，
    让调用方（run_all_reps）知道这次尝试整体失败，需要丢弃重来。
    """
    np.random.seed(seed)
    dim    = DIM_LAYER1
    bounds = BOUNDS
    nx     = N_INIT
    max_retries = 5

    # ── 初始 LHS ─────────────────────────────────────────────────────────────
    unit = lhs(len(bounds), samples=nx, criterion='maximin')
    X    = np.array([lo + (hi - lo) * unit[:, i]
                     for i, (lo, hi) in enumerate(bounds)]).T   # (nx, 2)
    X1_init = X[:, :dim]                      # (nx, 1)
    X2_init = X[:, dim].reshape(-1, 1)        # (nx, 1)  x2
    Y1_init = f1(X1_init)                     # (nx, 1)
    X2_full = np.hstack((Y1_init, X2_init))   # (nx, 2)  [y1, x2]
    Y2_init = f2(Y1_init, X2_init)            # (nx, 1)

    results = {}

    # ── EI（黑箱）────────────────────────────────────────────────────────────
    X_ei   = X.copy(); Y_ei = Y2_init.copy()
    cost_c = 0.0; failed = 0
    cost_log = [0.0]; y2_log = [float(Y2_init.min())]

    while cost_c + COST_BOTH <= SEQUENTIAL_BUDGET:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                m_ei = gp(X_ei, Y_ei,
                          kernel(length=np.ones(dim + 1), nugget=1e-6,
                                 name='matern2.5', scale_est=True))
                m_ei.train()
            bf = Y_ei.min()
            def acq(x):
                ml, vl = m_ei.predict(x.reshape(1, -1))
                return EI_from_ml_vl(ml.flat[0], vl.flat[0], bf)
            bx, ba = None, -1e20
            for _ in range(15):
                x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
                r  = minimize(lambda x: -acq(x), x0, bounds=bounds,
                              method='L-BFGS-B')
                if r.success and -r.fun > ba:
                    ba = -r.fun; bx = r.x
            if bx is None:
                bx = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
            x1n = bx[:dim].reshape(1, -1); x2n = bx[dim]
            y1n = f1(x1n); y2n = f2(y1n, np.array([[x2n]]))
            X_ei = np.vstack((X_ei, bx.reshape(1, -1)))
            Y_ei = np.vstack((Y_ei, y2n))
            cost_c += COST_BOTH; failed = 0
            cost_log.append(cost_c); y2_log.append(float(Y_ei.min()))
        except Exception as e:
            failed += 1
            if failed >= max_retries:
                raise RuntimeError(
                    f"[EI] seed={seed} 连续 {max_retries} 次异常，最后一次: {e}") from e

    results['EI'] = {
        'bsf': _bsf_curve(cost_log, y2_log),
        'final_best': float(Y_ei.min())
    }

    # ── EIFN ─────────────────────────────────────────────────────────────────
    eifn = EIFN_Optimizer(bounds)
    eifn.X1_data = X1_init.copy(); eifn.Y1_data = Y1_init.copy()
    eifn.X2_data = X2_full.copy(); eifn.Y2_data = Y2_init.copy()
    eifn.best_y2 = float(Y2_init.min())
    cost_c = 0.0; failed = 0
    cost_log = [0.0]; y2_log = [float(Y2_init.min())]

    while cost_c + COST_BOTH <= SEQUENTIAL_BUDGET:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                eifn.update_models()
                xn, _ = eifn.optimize_acquisition()
                eifn.add_observation(xn[:dim], xn[dim])
            cost_c += COST_BOTH; failed = 0
            cost_log.append(cost_c); y2_log.append(eifn.best_y2)
        except Exception as e:
            failed += 1
            if failed >= max_retries:
                raise RuntimeError(
                    f"[EIFN] seed={seed} 连续 {max_retries} 次异常，最后一次: {e}") from e

    results['EIFN'] = {
        'bsf': _bsf_curve(cost_log, y2_log),
        'final_best': eifn.best_y2
    }

    # ── EILGP ────────────────────────────────────────────────────────────────
    X1_el = X1_init.copy(); Y1_el = Y1_init.copy()
    X2_el = X2_full.copy(); Y2_el = Y2_init.copy()
    cost_c = 0.0; failed = 0
    cost_log = [0.0]; y2_log = [float(Y2_init.min())]

    while cost_c + COST_BOTH <= SEQUENTIAL_BUDGET:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                m1 = fit_gp1(X1_el, Y1_el)
                m2 = fit_gp2_connected(X2_el, Y2_el)
                lm = build_lgp_model(m1, m2)
            bf = Y2_el.min()
            bx, ba = None, -1e20
            for _ in range(15):
                x0 = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
                r  = minimize(lambda x: -standard_EI(x, lm, bf),
                              x0, bounds=bounds, method='L-BFGS-B')
                if r.success and -r.fun > ba:
                    ba = -r.fun; bx = r.x
            if bx is None:
                bx = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
            x1n = bx[:dim].reshape(1, -1); x2n = float(bx[dim])
            y1n = f1(x1n); y2n = f2(y1n, np.array([[x2n]]))
            X1_el = np.vstack((X1_el, x1n)); Y1_el = np.vstack((Y1_el, y1n))
            X2_el = np.vstack((X2_el, np.hstack((y1n, [[x2n]]))))
            Y2_el = np.vstack((Y2_el, y2n))
            cost_c += COST_BOTH; failed = 0
            cost_log.append(cost_c); y2_log.append(float(Y2_el.min()))
        except Exception as e:
            failed += 1
            if failed >= max_retries:
                raise RuntimeError(
                    f"[EILGP] seed={seed} 连续 {max_retries} 次异常，最后一次: {e}") from e

    results['EILGP'] = {
        'bsf': _bsf_curve(cost_log, y2_log),
        'final_best': float(Y2_el.min())
    }

    # ── CLEI（每次只在 layer1 / layer2_reuse 两种节点采集函数间比较）────────────
    X1_cl = X1_init.copy(); Y1_cl = Y1_init.copy()
    X2_cl = X2_full.copy(); Y2_cl = Y2_init.copy()
    cost_c = 0.0; failed = 0
    cost_log = [0.0]; y2_log = [float(Y2_init.min())]

    while cost_c < SEQUENTIAL_BUDGET:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                m1   = fit_gp1(X1_cl, Y1_cl)
                m2   = fit_gp2_connected(X2_cl, Y2_cl)
                c1   = container(m1.export(), local_input_idx=np.arange(dim))
                c2   = container(m2.export(), local_input_idx=np.array([0]))
                lm   = lgp([[c1], [c2]], N=10)
            bf = Y2_cl.min()

            strategy, opt_x, _, ei_vals = _clei_strategy(
                lm, m2, Y1_cl, bf, bounds, n_restart=15)
            ei_l1, ei_l2r = ei_vals

            cost_need = COST_LAYER1 if strategy == 'layer1' else COST_LAYER2
            if cost_c + cost_need > SEQUENTIAL_BUDGET:
                break

            min_dist = 1e-4

            if strategy == 'layer1':
                xd = np.array(opt_x).reshape(1, -1)
                if np.min(np.linalg.norm(X1_cl - xd, axis=1)) < min_dist:
                    xd = np.clip(xd + np.random.randn(1, dim) * 0.01,
                                 bounds[0][0], bounds[0][1])
                y1n = f1(xd)
                X1_cl = np.vstack((X1_cl, xd)); Y1_cl = np.vstack((Y1_cl, y1n))
                cost_c += COST_LAYER1

            else:  # 'layer2_reuse'
                y1s = float(opt_x[0]); x2s = float(opt_x[1])
                if np.min(np.linalg.norm(
                        X2_cl - np.array([[y1s, x2s]]), axis=1)) < min_dist:
                    x2s += np.random.randn() * 0.1
                y2n = f2(np.array([[y1s]]), np.array([[x2s]]))
                X2_cl = np.vstack((X2_cl, np.array([[y1s, x2s]])))
                Y2_cl = np.vstack((Y2_cl, y2n))
                cost_c += COST_LAYER2

            failed = 0
            cost_log.append(cost_c); y2_log.append(float(Y2_cl.min()))

        except Exception as e:
            failed += 1
            if failed >= max_retries:
                raise RuntimeError(
                    f"[CLEI] seed={seed} 连续 {max_retries} 次异常，最后一次: {e}") from e

    results['CLEI'] = {
        'bsf': _bsf_curve(cost_log, y2_log),
        'final_best': float(Y2_cl.min())
    }

    return results


# =============================================================================
# 50 次重复 & 汇总
# =============================================================================

def run_all_reps(n_reps=N_REPS, base_seed=BASE_SEED, save_file=SAVE_FILE,
                  max_attempts_per_rep=MAX_ATTEMPTS_PER_REP):
    """
    运行所有重复实验，保存结果，返回汇总统计。

    若某次重复（四种方法中任意一种）在拟合/优化过程中连续异常、
    重试用尽，则丢弃这一整次重复的所有结果，换一个新的随机种子重新
    完整跑一遍，直到成功（四种方法都正常跑满预算）为止，才计入第 i 次
    重复。最多尝试 max_attempts_per_rep 次；如果全部尝试都失败，
    才放弃该次重复（记为 None），避免真的陷入死循环。
    """

    # ── 尝试加载已有结果 ─────────────────────────────────────────────────────
    if os.path.exists(save_file):
        print(f"[Cache] 加载已有结果: {save_file}")
        with open(save_file, 'rb') as f:
            all_results = pickle.load(f)
    else:
        all_results = []

    start_rep = len(all_results)
    if start_rep < n_reps:
        print(f"[Run] 从第 {start_rep + 1} 次开始，共需完成 {n_reps} 次。")
        for i in range(start_rep, n_reps):
            res = None
            success = False
            for attempt in range(max_attempts_per_rep):
                # 第一次尝试用常规 seed；失败后换一个新 seed 重新完整跑，
                # 避免用同一个 seed 反复触发完全相同的确定性失败。
                if attempt == 0:
                    trial_seed = base_seed + i
                else:
                    trial_seed = base_seed + n_reps * (attempt + 1) + i

                label = f"  Rep {i + 1:02d}/{n_reps}"
                if attempt > 0:
                    label += f"（第 {attempt + 1} 次重新开始）"
                print(f"{label}  seed={trial_seed}", end=' ... ', flush=True)

                try:
                    res = _run_one(trial_seed)
                    success = True
                    print(f"EI best={res['EI']['final_best']:.4f}  "
                          f"EIFN best={res['EIFN']['final_best']:.4f}  "
                          f"EILGP best={res['EILGP']['final_best']:.4f}  "
                          f"CLEI best={res['CLEI']['final_best']:.4f}")
                    break
                except Exception as e:
                    print(f"异常，丢弃本次重复的全部结果，重新开始: {e}")

            if not success:
                print(f"  [ERROR] Rep {i + 1} 连续 {max_attempts_per_rep} 次尝试均失败，"
                      f"放弃该次重复（记为 None）。")
                res = None

            all_results.append(res)

            # 每 5 次保存一次（断点续算）
            if (i + 1) % 5 == 0:
                with open(save_file, 'wb') as f:
                    pickle.dump(all_results, f)
                print(f"  [Saved] {save_file}")

        # 最终保存
        with open(save_file, 'wb') as f:
            pickle.dump(all_results, f)
        print(f"[Saved] 全部结果已保存至 {save_file}")
    else:
        print(f"[Cache] 已有 {len(all_results)} 次结果，跳过运算。")

    return all_results


def summarize(all_results):
    """
    汇总 50 次结果：
      1. 各方法最终最优值的均值 ± 标准差
      2. 各方法 best-so-far 曲线的均值（用于后续绘图）
    """
    valid = [r for r in all_results if r is not None]
    n     = len(valid)
    print(f"\n{'=' * 60}")
    print(f"汇总结果（有效重复次数: {n}/{len(all_results)}）")
    print(f"{'=' * 60}")

    print(f"\n{'方法':<12} {'均值':>10} {'标准差':>10} {'最好':>10} {'最差':>10}")
    print('-' * 54)

    mean_curves = {}
    for method in METHODS:
        finals = [r[method]['final_best'] for r in valid]
        bsf_stack = np.array([r[method]['bsf'] for r in valid])  # (n, T)
        mean_bsf  = np.nanmean(bsf_stack, axis=0)
        mean_curves[method] = mean_bsf

        mu  = np.mean(finals)
        std = np.std(finals)
        print(f"  {method:<10} {mu:>10.4f} {std:>10.4f} "
              f"{min(finals):>10.4f} {max(finals):>10.4f}")

    # 按均值排名
    finals_mean = {m: np.mean([r[m]['final_best'] for r in valid])
                   for m in METHODS}
    ranked = sorted(finals_mean.items(), key=lambda kv: kv[1])
    print(f"\n排名（最终最优均值，越小越好）：")
    for rank, (m, v) in enumerate(ranked, 1):
        print(f"  #{rank}  {m:<10}  {v:.4f}")

    # best-so-far 曲线摘要（每隔 10 个代价单位打印一次）
    step = max(1, len(COST_AXIS) // 10)
    print(f"\n平均 best-so-far 曲线（代价步长 ~{COST_AXIS[step]:.0f}）：")
    header = f"{'Cost':>6}" + "".join(f"  {m:>10}" for m in METHODS)
    print(header)
    print('-' * (6 + 12 * len(METHODS)))
    for idx in range(0, len(COST_AXIS), step):
        row = f"{COST_AXIS[idx]:>6.0f}"
        for m in METHODS:
            val = mean_curves[m][idx]
            row += f"  {val:>10.4f}" if not np.isnan(val) else f"  {'NaN':>10}"
        print(row)

    print(f"\n{'=' * 60}")
    return mean_curves, finals_mean


# =============================================================================
# 主程序
# =============================================================================

if __name__ == '__main__':
    print("GP-Network 测试问题（50 次重复实验）")
    print(f"  函数结构：x1→y1→f2(y1,x2)→y2，最小化 y2")
    print(f"  预算={SEQUENTIAL_BUDGET}，代价比={COST_LAYER1}:{COST_LAYER2}")
    print(f"  CLEI 每次只在 layer1 / layer2_reuse 两种节点采集函数间比较（已移除 both 选项）")
    print(f"  任一方法异常重试用尽将丢弃整次重复并换新种子重新开始（上限 {MAX_ATTEMPTS_PER_REP} 次尝试）")
    print(f"  重复次数={N_REPS}，结果保存至 {SAVE_FILE}\n")

    # 运行 / 加载
    all_results = run_all_reps(N_REPS, BASE_SEED, SAVE_FILE)

    # 汇总打印
    mean_curves, finals_mean = summarize(all_results)

    print("\nDone.")