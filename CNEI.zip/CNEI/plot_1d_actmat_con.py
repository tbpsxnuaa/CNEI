# import pandas as pd
# import matplotlib
# matplotlib.use('TkAgg')
# import matplotlib.pyplot as plt
# import numpy as np
# import os, re
#
# plt.rcParams['font.family'] = 'Times New Roman'
# plt.rcParams['font.size'] = 14        # 全局基础字号
# plt.rcParams['axes.titlesize'] = 15   # 子图标题
# plt.rcParams['axes.labelsize'] = 14   # 轴标签
# plt.rcParams['xtick.labelsize'] = 13  # x轴刻度
# plt.rcParams['ytick.labelsize'] = 13  # y轴刻度
# plt.rcParams['legend.fontsize'] = 13  # 图例
#
# # ── 配置 ──────────────────────────────────────────────
# DATA_DIR    = r"D:\python code\linked_bo\bo_results\results_1d"
# OUTPUT_FILE = r"D:\python code\linked_bo\bo_results\1d_convergence_boxplot.pdf"
# TARGET_RATIO = "1:9"   # 目标 cost ratio
# Y_MIN        = 0       # log10(y - y_min) 中的 y_min
# # ──────────────────────────────────────────────────────
#
# # algos 用于匹配文件名中的内部名称，顺序即控制画图/图例/箱线图的顺序
# algos  = ['EI', 'EIFN', 'EILGP', 'CLEI']
# colors = {'EI': '#1f77b4', 'CLEI': '#ff7f0e', 'EIFN': '#2ca02c', 'EILGP': '#d62728'}
#
# # 显示名称映射：内部仍用 CLEI 匹配文件，但展示时改为 CNEI
# display_name = {'EI': 'EI', 'EIFN': 'EIFN', 'EILGP': 'EILGP', 'CLEI': 'CNEI'}
#
# files = sorted([
#     f for f in os.listdir(DATA_DIR)
#     if "convergence" in f and f.endswith(".xlsx")
# ])
#
# # 解析目标 cost ratio 的数据
# conv_data = {}   # algo -> (costs, mean, std)
# best_data = {}   # algo -> array of best values (length 100)
#
# for f in files:
#     m = re.search(r'1D_(\d+)_(\d+)_(\w+)_convergence', f)
#     if not m:
#         continue
#     c1, c2, algo = m.group(1), m.group(2), m.group(3)
#     if f"{c1}:{c2}" != TARGET_RATIO:
#         continue
#
#     df    = pd.read_excel(os.path.join(DATA_DIR, f))
#     costs = df['cumulative_cost'].values
#     vals  = df.iloc[:, 1:].values  # shape: (n_iters, 100)
#
#     # ── 收敛图：log10(y - y_min) 的均值 ± 标准差 ──
#     shifted  = np.where(vals - Y_MIN > 0, vals - Y_MIN, np.nan)
#     log_vals = np.log10(shifted)
#     mean = np.nanmean(log_vals, axis=1)
#     std  = np.nanstd(log_vals, axis=1)
#     conv_data[algo] = (costs, mean, std)
#
#     # ── 箱线图：每次实验最终一代的最优值（最后一行） ──
#     best_data[algo] = vals[-1, :]   # 取最后一行，即最终最优值
#
# # ── 绘图 ──────────────────────────────────────────────
# # 用 gridspec_kw 的 wspace 控制左右两个子图之间的水平间距，数值越大间距越宽
# fig, axes = plt.subplots(1, 2, figsize=(13, 5), gridspec_kw={'wspace': 0.5})
#
# # ---------- 左图：收敛图 ----------
# ax = axes[0]
# for algo in algos:
#     if algo not in conv_data:
#         continue
#     costs, mean, std = conv_data[algo]
#     ax.plot(costs, mean, color=colors[algo], label=display_name.get(algo, algo), linewidth=1.8)
#     ax.fill_between(costs, mean - std, mean + std, color=colors[algo], alpha=0.2)
#
# ax.set_xlabel('Cumulative Cost', fontsize=11)
# ax.set_ylabel(r'$\log_{10}(y - y_{\min})$', fontsize=11)
# ax.legend(fontsize=10)
# ax.grid(True, alpha=0.3)
#
# # ---------- 右图：箱线图 ----------
# ax = axes[1]
# plot_algos  = [a for a in algos if a in best_data]
# box_data    = [best_data[a] for a in plot_algos]
# box_colors  = [colors[a] for a in plot_algos]
# box_labels  = [display_name.get(a, a) for a in plot_algos]
#
# bp = ax.boxplot(
#     box_data,
#     labels=box_labels,
#     patch_artist=True,
#     medianprops=dict(color='black', linewidth=1.5),
#     whiskerprops=dict(linewidth=1.2),
#     capprops=dict(linewidth=1.2),
#     flierprops=dict(marker='o', markersize=4, linestyle='none', alpha=0.5),
# )
# for patch, color in zip(bp['boxes'], box_colors):
#     patch.set_facecolor(color)
#     patch.set_alpha(0.6)
#
# # ax.set_xlabel('Methods', fontsize=13)
# ax.set_ylabel('Best Objective Found', fontsize=13)
# ax.grid(True, axis='y', alpha=0.3)
#
# fig.text(0.27, -0.04, f'(a) Optimality gap over 100 replications by each method',
#          ha='center', fontsize=14)
# fig.text(0.73, -0.04, f'(b) The objective values found by each method)',
#          ha='center', fontsize=14)
#
# # 先用 tight_layout 做基础排版，再用 subplots_adjust 显式加宽间距，避免被 tight_layout 覆盖
# plt.tight_layout()
# plt.subplots_adjust(wspace=0.5)
#
# plt.savefig(OUTPUT_FILE, bbox_inches='tight')
# print(f"Saved to {OUTPUT_FILE}")
# plt.show()

"""
Plot BO algorithm comparison: convergence vs cost (left) + final best-value boxplot (right).

Reads the 4-algorithm convergence xlsx set and produces a 1x2 figure.
Each *_convergence.xlsx file:
  - column 'cumulative_cost': budget axis (0..100)
  - remaining columns: one best-so-far value per experiment/seed (minimization)
"""
import os
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

# ---- config -------------------------------------------------------------
DATA_DIR    = r"D:\python code\linked_bo\bo_results\results_1d"
PREFIX = "1D_1_9_"                # cost ratio 1:9, cost 0-500
SUFFIX = "_convergence.xlsx"

YLOG = True           # True: log y-axis; False: linear
BAND = "sem95"        # "se" | "sem95" | "std" | "iqr" | "none"

# titles (placed BELOW each subplot)
TITLE_L = "(a) Convergence of the best objective value over 100 replications"
TITLE_R = "(b) Final best objective value by each method"

# ---- font sizes (bumped up to match paper body text) --------------------
FS_BASE   = 16   # default text
FS_LABEL  = 18   # axis labels
FS_TICK   = 15   # tick labels
FS_LEGEND = 16   # legend
FS_TITLE  = 17   # sub-caption below each panel

# Times New Roman if available (Windows), else metric-identical fallbacks
plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Times New Roman", "Liberation Serif",
                              "Nimbus Roman", "DejaVu Serif"]
plt.rcParams["mathtext.fontset"] = "dejavuserif"
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams.update({
    "font.size": FS_BASE,
    "axes.labelsize": FS_LABEL,
    "xtick.labelsize": FS_TICK,
    "ytick.labelsize": FS_TICK,
    "legend.fontsize": FS_LEGEND,
    "axes.linewidth": 1.0,
})

# algorithm label -> filename
ALGOS = {
    "EI":    PREFIX + "EI" + SUFFIX,
    "EIFN":  PREFIX + "EIFN" + SUFFIX,
    "EILGP": PREFIX + "EILGP" + SUFFIX,
    "CLEI":  PREFIX + "CLEI" + SUFFIX,
}
COLORS = {
    "EI":    "#1f77b4",
    "EIFN":  "#ff7f0e",
    "EILGP": "#2ca02c",
    "CLEI":  "#d62728",
}
LABELS = {"CLEI": "CNEI"}   # display name only; files stay CLEI
STYLES = {"EI": ":", "EIFN": "-.", "EILGP": "--", "CLEI": "-"}   # line styles
OUT_PDF = os.path.join(DATA_DIR, "convergence_boxplot_1d19_styled.pdf")

# ---- load ---------------------------------------------------------------
conv = {}      # algo -> (cost, center, lo, hi) over runs
finals = {}    # algo -> array of final best values per run
for name, fname in ALGOS.items():
    df = pd.read_excel(os.path.join(DATA_DIR, fname))
    cost = df["cumulative_cost"].values.astype(float)
    vals = df.drop(columns=["cumulative_cost"]).values.astype(float)  # rows=cost, cols=runs
    n = vals.shape[1]
    mean = vals.mean(axis=1)
    std = vals.std(axis=1)
    if BAND == "se":
        center, lo, hi = mean, mean - std / np.sqrt(n), mean + std / np.sqrt(n)
    elif BAND == "sem95":
        try:
            from scipy.stats import t as _t
            tv = _t.ppf(0.975, n - 1)
        except Exception:
            tv = 1.96
        h = tv * std / np.sqrt(n)
        center, lo, hi = mean, mean - h, mean + h
    elif BAND == "std":
        center, lo, hi = mean, mean - std, mean + std
    elif BAND == "iqr":
        center = np.median(vals, axis=1)
        lo = np.percentile(vals, 25, axis=1)
        hi = np.percentile(vals, 75, axis=1)
    else:  # none
        center, lo, hi = mean, mean, mean
    if not YLOG:
        lo = np.clip(lo, 0, None)
    conv[name] = (cost, center, lo, hi)
    finals[name] = vals[-1]

# ---- plot ---------------------------------------------------------------
fig, (axL, axR) = plt.subplots(1, 2, figsize=(13, 5.6))

# left: convergence
_ylab = {"se": "mean $\\pm$ SE", "sem95": "mean, 95% CI",
         "std": "mean $\\pm$ std", "iqr": "median + IQR", "none": "mean"}[BAND]
for name in ALGOS:
    cost, center, lo, hi = conv[name]
    axL.plot(cost, center, label=LABELS.get(name, name), color=COLORS[name],
             linestyle=STYLES[name], linewidth=2.2)
    if BAND != "none":
        axL.fill_between(cost, lo, hi, color=COLORS[name], alpha=0.15)
axL.set_xlabel("Cumulative cost")
axL.set_ylabel("Best value found (" + _ylab + ")")
axL.set_title(TITLE_L, fontsize=FS_TITLE, pad=10)
if YLOG:
    axL.set_yscale("log")
axL.grid(True, which="both", ls="--", lw=0.5, alpha=0.5)
axL.legend(frameon=False)
axL.set_xlim(cost.min(), cost.max())

# right: boxplot of final best values
labels = list(ALGOS.keys())
data = [finals[n] for n in labels]
bp = axR.boxplot(data, tick_labels=[LABELS.get(l, l) for l in labels],
                 patch_artist=True, showmeans=True,
                 widths=0.6,
                 medianprops=dict(color="black", linewidth=1.6),
                 meanprops=dict(marker="D", markerfacecolor="white",
                                markeredgecolor="black", markersize=7),
                 flierprops=dict(marker="o", markersize=3.5, alpha=0.4))
for patch, n in zip(bp["boxes"], labels):
    patch.set_facecolor(COLORS[n])
    patch.set_alpha(0.55)
axR.set_ylabel("Final best value")
axR.set_title(TITLE_R, fontsize=FS_TITLE, pad=10)
axR.grid(True, axis="y", ls="--", lw=0.5, alpha=0.5)
axR.yaxis.set_major_locator(MaxNLocator(nbins=8))

fig.tight_layout()
fig.subplots_adjust(bottom=0.18)
fig.savefig(OUT_PDF, bbox_inches="tight")
print("saved:", OUT_PDF)